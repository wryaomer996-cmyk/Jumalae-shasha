import React, { useRef, useState } from 'react';
import { Invoice, Customer } from '../types';
import { useStore } from '../context/StoreContext';
import { X, Printer, Share2, Phone, MapPin, Smartphone, AlertCircle, Sliders } from 'lucide-react';

interface InvoiceReceiptModalProps {
  invoice: Invoice | null;
  customer?: Customer;
  onClose: () => void;
}

export const InvoiceReceiptModal: React.FC<InvoiceReceiptModalProps> = ({
  invoice,
  customer,
  onClose,
}) => {
  const { customers, settings } = useStore();
  const printRef = useRef<HTMLDivElement>(null);
  const [paperFormat, setPaperFormat] = useState<'80mm' | '58mm' | 'standard'>(
    settings.thermalPaperWidth || '80mm'
  );

  if (!invoice) return null;

  const currentCustomer = customer || customers.find((c) => c.id === invoice.customerId);

  const handlePrint = () => {
    window.print();
  };

  const shareViaWhatsApp = () => {
    if (!currentCustomer) return;
    const itemsList = invoice.items
      .map((item, idx) => `${idx + 1}. ${item.name} (${item.quantity} دانە) - ${item.total.toLocaleString()} دینار`)
      .join('\n');

    const message = `*${settings.shopName} - پسوولەی وەسڵ* 📱\n` +
      `ژمارەی وەسڵ: #${invoice.id}\n` +
      `بەروار: ${invoice.date}\n` +
      `کڕیار / وەستا: ${currentCustomer.name}\n` +
      `مۆبایل: ${currentCustomer.phone}\n\n` +
      `*شاشە و کەلوپەلەکان:*\n${itemsList}\n\n` +
      `کۆی گشتی وەسڵ: ${invoice.totalAmount.toLocaleString()} دینار\n` +
      `بڕی پارەدراو: ${invoice.paidAmount.toLocaleString()} دینار\n` +
      `قەرزی پێشوو: ${invoice.previousDebt.toLocaleString()} دینار\n` +
      `*قەرزی ماوە: ${invoice.remainingDebt.toLocaleString()} دینار*\n\n` +
      `*تێبینی گەرەنتی:*\n${settings.warrantyTerms}\n\n` +
      `سوپاس بۆ متمانەتان - ${settings.shopName}\n` +
      `ناونیشان: ${settings.address}\n` +
      `تەلەفۆن: ${settings.phone1}`;

    const encoded = encodeURIComponent(message);
    const phoneClean = currentCustomer.phone.replace(/[^0-9]/g, '');
    const fullPhone = phoneClean.startsWith('0') ? '964' + phoneClean.slice(1) : phoneClean;
    window.open(`https://wa.me/${fullPhone}?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #thermal-receipt-printable, #thermal-receipt-printable * {
            visibility: visible;
          }
          #thermal-receipt-printable {
            position: absolute;
            left: 0;
            top: 0;
            width: ${paperFormat === '58mm' ? '54mm' : paperFormat === '80mm' ? '76mm' : '100%'};
            margin: 0 auto;
            padding: 4px;
            font-size: ${paperFormat === '58mm' ? '11px' : '12px'};
            background: white !important;
            color: black !important;
          }
          @page {
            margin: 0;
            size: ${paperFormat === '58mm' ? '58mm auto' : paperFormat === '80mm' ? '80mm auto' : 'auto'};
          }
        }
      `}</style>

      <div className={`relative w-full bg-white rounded-2xl shadow-2xl overflow-hidden my-6 border border-slate-200 transition-all ${
        paperFormat === '58mm' ? 'max-w-sm' : paperFormat === '80mm' ? 'max-w-md' : 'max-w-xl'
      }`}>
        {/* Modal Action Bar - Hidden during printing */}
        <div className="no-print flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800 text-sm sm:text-base">پسوولەی وەسڵ</span>
            <span className="bg-purple-100 text-purple-700 text-xs px-2 py-0.5 rounded-full font-mono font-bold">
              #{invoice.id}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Paper Size selector */}
            <select
              value={paperFormat}
              onChange={(e: any) => setPaperFormat(e.target.value)}
              className="text-xs bg-white border border-slate-200 rounded-lg px-2 py-1.5 font-bold text-slate-700 focus:outline-purple-600 cursor-pointer"
              title="قەبارەی چاپکەر (Thermal Printer Size)"
            >
              <option value="80mm">🖨️ تێرمەڵ 80mm</option>
              <option value="58mm">🧾 تێرمەڵ 58mm</option>
              <option value="standard">📄 پەڕەی ئاسایی A4</option>
            </select>

            <button
              onClick={shareViaWhatsApp}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition cursor-pointer"
              title="ناردن بە وەتسئەپ"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">وەتسئەپ</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition shadow-sm cursor-pointer"
              title="چاپکردن"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>چاپ</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Paper */}
        <div id="thermal-receipt-printable" ref={printRef} className={`p-5 sm:p-6 bg-white text-slate-800 font-sans print:p-1 print:m-0 ${
          paperFormat === '58mm' ? 'text-xs leading-tight' : 'text-xs'
        }`}>
          {/* Header Brand from Settings */}
          <div className="text-center pb-5 border-b-2 border-dashed border-slate-300">
            <div className="w-14 h-14 mx-auto mb-2 bg-gradient-to-tr from-purple-600 to-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-md">
              <Smartphone className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight">{settings.shopName}</h2>
            <p className="text-xs font-semibold text-purple-700 mt-0.5">{settings.subTitle}</p>
            <p className="text-xs text-slate-500 mt-1 flex items-center justify-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              <span>{settings.address}</span>
            </p>
            <p className="text-xs text-slate-500 mt-0.5 flex items-center justify-center gap-1">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span dir="ltr">{settings.phone1} {settings.phone2 ? ` / ${settings.phone2}` : ''}</span>
            </p>
          </div>

          {/* Invoice Meta Grid */}
          <div className="grid grid-cols-2 gap-3 py-4 text-xs border-b border-slate-200">
            <div>
              <span className="text-slate-500 block">ژمارەی وەسڵ:</span>
              <span className="font-bold text-slate-800 text-sm font-mono">#{invoice.id}</span>
            </div>
            <div className="text-left">
              <span className="text-slate-500 block">بەروار و کات:</span>
              <span className="font-medium text-slate-800 text-xs font-mono" dir="ltr">{invoice.date}</span>
            </div>
            <div>
              <span className="text-slate-500 block">ناوی وەستا / کڕیار:</span>
              <span className="font-bold text-slate-900 text-sm">{currentCustomer?.name || 'کڕیاری گشتی'}</span>
            </div>
            <div className="text-left">
              <span className="text-slate-500 block">ژمارەی مۆبایل:</span>
              <span className="font-medium text-slate-800 font-mono" dir="ltr">{currentCustomer?.phone || '-'}</span>
            </div>
            <div>
              <span className="text-slate-500 block">لق:</span>
              <span className="font-medium text-slate-700">{invoice.branch || 'سەرەکی'}</span>
            </div>
            <div className="text-left">
              <span className="text-slate-500 block">جۆری مامەڵە:</span>
              <span className="inline-block px-2 py-0.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700">
                {invoice.type === 'Wholesale' ? 'جوملە' : invoice.type}
              </span>
            </div>
          </div>

          {/* Items Table */}
          <div className="py-4 border-b border-slate-200">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="text-slate-500 border-b border-slate-200">
                  <th className="pb-2">ماددە / شاشە</th>
                  <th className="pb-2 text-center">دانە</th>
                  <th className="pb-2 text-left">نرخی دانە</th>
                  <th className="pb-2 text-left">کۆی گشتی</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoice.items.map((item, idx) => (
                  <tr key={idx} className="py-2">
                    <td className="py-2.5 font-medium text-slate-800">
                      {item.name}
                      {item.quality && (
                        <span className="mr-1.5 text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                          {item.quality}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 text-center font-mono">{item.quantity}</td>
                    <td className="py-2.5 text-left font-mono text-slate-600">
                      {item.price.toLocaleString()}
                    </td>
                    <td className="py-2.5 text-left font-mono font-bold text-slate-900">
                      {item.total.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Calculations Summary */}
          <div className="pt-4 pb-2 space-y-1.5 text-xs text-slate-700">
            <div className="flex justify-between py-1">
              <span className="text-slate-500">کۆی گشتی وەسڵ:</span>
              <span className="font-bold font-mono text-sm">{invoice.totalAmount.toLocaleString()} دینار</span>
            </div>

            {invoice.discount > 0 && (
              <div className="flex justify-between py-1 text-slate-600">
                <span>داشکاندن:</span>
                <span className="font-mono">-{invoice.discount.toLocaleString()} دینار</span>
              </div>
            )}

            <div className="flex justify-between py-1 text-emerald-700 font-semibold">
              <span>پارەدراو بە کاش:</span>
              <span className="font-mono">{invoice.paidAmount.toLocaleString()} دینار</span>
            </div>

            <div className="flex justify-between py-1 text-slate-500">
              <span>قەرزی پێشوو:</span>
              <span className="font-mono">{invoice.previousDebt.toLocaleString()} دینار</span>
            </div>

            <div className="flex justify-between py-2 border-t-2 border-slate-800 font-black text-rose-600 text-base">
              <span>کۆی قەرزی ماوە:</span>
              <span className="font-mono">{invoice.remainingDebt.toLocaleString()} دینار</span>
            </div>
          </div>

          {/* Warranty Terms Note */}
          <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
            <strong className="block text-slate-800 font-bold mb-0.5">مەرجی گەرەنتی شاشە:</strong>
            {settings.warrantyTerms}
          </div>

          {/* Signature / Footer */}
          <div className="mt-6 pt-4 border-t border-slate-200 flex justify-between text-[11px] text-slate-400">
            <div>مۆری فرۆشگا / واژوو: .................</div>
            <div>واژووی کڕیار: .................</div>
          </div>
        </div>
      </div>
    </div>
  );
};
