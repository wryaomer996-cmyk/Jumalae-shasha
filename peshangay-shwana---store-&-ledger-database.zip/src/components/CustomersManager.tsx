import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Customer } from '../types';
import { 
  Users, 
  Search, 
  UserPlus, 
  Phone, 
  MapPin, 
  Lock, 
  CreditCard, 
  ExternalLink, 
  Copy, 
  Check, 
  Edit, 
  Trash2, 
  MessageCircle,
  AlertCircle 
} from 'lucide-react';

interface CustomersManagerProps {
  onOpenCustomerPortal: (customerId: number) => void;
}

export const CustomersManager: React.FC<CustomersManagerProps> = ({ onOpenCustomerPortal }) => {
  const { customers, settings, addCustomer, updateCustomer, deleteCustomer, getCustomerStats, recordPayment, formatMoney } = useStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Payment Recording Modal
  const [paymentCustomer, setPaymentCustomer] = useState<Customer | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentNotes, setPaymentNotes] = useState('');

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [passcode, setPasscode] = useState('');
  const [notes, setNotes] = useState('');

  const [copiedId, setCopiedId] = useState<number | null>(null);

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm) ||
      c.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.id.toString().includes(searchTerm) ||
      c.passcode.includes(searchTerm)
  );

  const handleOpenAdd = () => {
    setName('');
    setPhone('');
    setAddress('حاجیاوا');
    // Generate 3 digit passcode
    setPasscode(Math.floor(100 + Math.random() * 899).toString());
    setNotes('');
    setEditingCustomer(null);
    setShowAddModal(true);
  };

  const handleOpenEdit = (c: Customer) => {
    setEditingCustomer(c);
    setName(c.name);
    setPhone(c.phone);
    setAddress(c.address);
    setPasscode(c.passcode);
    setNotes(c.notes || '');
    setShowAddModal(true);
  };

  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    if (editingCustomer) {
      updateCustomer(editingCustomer.id, {
        name,
        phone,
        address,
        passcode: passcode || '262',
        notes,
      });
    } else {
      addCustomer({
        name,
        phone,
        address,
        passcode: passcode || '262',
        notes,
      });
    }

    setShowAddModal(false);
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentCustomer || paymentAmount <= 0) return;

    recordPayment(paymentCustomer.id, paymentAmount, paymentNotes);
    setPaymentCustomer(null);
    setPaymentAmount(0);
    setPaymentNotes('');
  };

  const copyCustomerLink = (c: Customer) => {
    const origin = window.location.origin;
    const url = `${origin}/?code=${c.passcode}`;
    navigator.clipboard.writeText(url);
    setCopiedId(c.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const sendWhatsAppPortalLink = (c: Customer) => {
    const origin = window.location.origin;
    const stats = getCustomerStats(c.id);
    const link = `${origin}/?code=${c.passcode}`;

    const text = `*سڵاو وەستا ${c.name} گیان* 📱\n` +
      `ئەمەش لینکی حسابی تایبەتی خۆتە لە *${settings.shopName}*:\n` +
      `دەتوانیت بەم کۆدە تایبەتەی خۆت سەرجەم وەسڵەکانت، قەرزی ماوەت و نرخی جوملەی سەرجەم شاشەکان ببینیت:\n` +
      `🔑 کۆدی نهێنی تایبەتی تۆ: *${c.passcode}*\n` +
      `🔗 لینک: ${link}\n` +
      `💰 کۆی قەرزی ئێستای سەر تۆ: *${stats.totalDebt.toLocaleString()} دینار*\n\n` +
      `${settings.shopName} - ${settings.address}\n` +
      `تەلەفۆن: ${settings.phone1}`;

    const cleanPhone = c.phone.replace(/[^0-9]/g, '');
    const fullPhone = cleanPhone.startsWith('0') ? '964' + cleanPhone.slice(1) : cleanPhone;
    window.open(`https://wa.me/${fullPhone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
        <div>
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
            <Users className="w-6 h-6 text-purple-600" />
            <span>بەڕێوەبردنی کڕیاران و وەستاکان (Technicians & Customers)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            دروستکردنی لینکی وەستا، دانانی کۆدی نهێنی و وەرگرتنەوەی قەرز
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="گەڕان بەپێی ناو، ژمارە، کۆد..."
              className="bg-slate-50 border border-slate-200 rounded-xl pr-9 pl-4 py-2 text-xs font-bold focus:outline-purple-600 w-60"
            />
          </div>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>کڕیار / وەستای نوێ</span>
          </button>
        </div>
      </div>

      {/* Customers List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCustomers.map((c) => {
          const stats = getCustomerStats(c.id);
          const hasDebt = stats.totalDebt > 0;

          return (
            <div
              key={c.id}
              className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 hover:border-purple-300 transition flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-xs font-bold bg-purple-100 text-purple-700 px-1.5 py-0.5 rounded">
                        #{c.id}
                      </span>
                      <h3 className="font-black text-slate-900 text-base">{c.name}</h3>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span dir="ltr" className="font-mono">{c.phone}</span>
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        <span>{c.address || 'حاجیاوا'}</span>
                      </span>
                    </div>
                  </div>

                  {/* Passcode Badge */}
                  <div className="text-left bg-purple-50 px-2.5 py-1 rounded-xl border border-purple-200">
                    <span className="text-[10px] text-purple-700 font-bold block">کۆدی وەستا:</span>
                    <span className="font-mono font-black text-sm text-purple-900">
                      {c.passcode}
                    </span>
                  </div>
                </div>

                {c.notes && (
                  <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded-xl mb-3 border border-slate-100 line-clamp-2">
                    {c.notes}
                  </p>
                )}

                {/* Financial Overview */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center">
                  <div>
                    <span className="text-[10px] text-slate-400 block">کۆی وەسڵ:</span>
                    <span className="text-xs font-black font-mono text-slate-800">
                      {stats.totalInvoicesAmount.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">پارەی دراو:</span>
                    <span className="text-xs font-black font-mono text-emerald-600">
                      {stats.totalPaidAmount.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">قەرزی ماوە:</span>
                    <span
                      className={`text-xs font-black font-mono ${
                        hasDebt ? 'text-rose-600' : 'text-slate-500'
                      }`}
                    >
                      {stats.totalDebt.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => sendWhatsAppPortalLink(c)}
                    className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-xl transition cursor-pointer"
                    title="ناردنی وەسڵ و لینک بۆ وەستا بە وەتسئەپ"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => copyCustomerLink(c)}
                    className="p-2 text-slate-500 hover:text-purple-600 hover:bg-purple-50 rounded-xl transition cursor-pointer"
                    title="کۆپیکردنی لینکی وەستا"
                  >
                    {copiedId === c.id ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={() => onOpenCustomerPortal(c.id)}
                    className="p-2 text-purple-600 hover:bg-purple-50 rounded-xl transition cursor-pointer"
                    title="کردنەوەی پۆرتاڵی وەستا"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center gap-1.5">
                  {hasDebt && (
                    <button
                      onClick={() => {
                        setPaymentCustomer(c);
                        setPaymentAmount(stats.totalDebt);
                        setPaymentNotes(`دانەوەی تەواوی قەرز: ${stats.totalDebt.toLocaleString()} دینار`);
                      }}
                      className="px-2.5 py-1 text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg transition cursor-pointer"
                    >
                      دانەوەی قەرز
                    </button>
                  )}

                  <button
                    onClick={() => handleOpenEdit(c)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      if (confirm(`ئایا دڵنیایت دەتەوێت "${c.name}" بسڕیتەوە؟`)) {
                        deleteCustomer(c.id);
                      }
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white text-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200">
            <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-purple-600" />
              <span>{editingCustomer ? 'دەستکاریکردنی کڕیار / وەستا' : 'تۆمارکردنی کڕیاری نوێ'}</span>
            </h3>

            <form onSubmit={handleSaveCustomer} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ناوی سیانی:</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="ناوی وەستا یان کڕیار..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-purple-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ژمارەی مۆبایل:</label>
                <input
                  type="text"
                  required
                  dir="ltr"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0750xxxxxxx"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-purple-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">شوێن / ناونیشان:</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="شوێن / ناونیشان..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">کۆدی نهێنی (3 ژمارە):</label>
                  <input
                    type="text"
                    dir="ltr"
                    maxLength={6}
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    placeholder="کۆدی نهێنی..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-purple-600 text-center"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">تێبینی:</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="وەستای چاککردنەوە، کڕیاری شاشەی ئەسڵی..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-purple-600"
                />
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  پاشگەزبوونەوە
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-sm"
                >
                  پاشەکەوتکردن
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {paymentCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white text-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200">
            <h3 className="text-lg font-black text-slate-900 mb-2 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-emerald-600" />
              <span>وەرگرتن و دانەوەی قەرز</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              وەرگرتنی پارە لە وەستا: <strong className="text-slate-800">{paymentCustomer.name}</strong>
            </p>

            <form onSubmit={handleRecordPaymentSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">بڕی پارەدراو (دینار):</label>
                <input
                  type="number"
                  required
                  min={500}
                  value={paymentAmount || ''}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-sm font-mono font-bold focus:outline-purple-600 text-left"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">تێبینی وەسڵ:</label>
                <input
                  type="text"
                  value={paymentNotes}
                  onChange={(e) => setPaymentNotes(e.target.value)}
                  placeholder="دانەوەی قەرز..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-purple-600"
                />
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setPaymentCustomer(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  داخستن
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-sm"
                >
                  تۆمارکردن
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
