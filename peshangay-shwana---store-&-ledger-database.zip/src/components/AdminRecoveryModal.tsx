import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { ShieldAlert, KeyRound, CheckCircle2, AlertCircle, Mail, Phone, Lock, Eye, EyeOff, X, ArrowRight, Sparkles } from 'lucide-react';

interface AdminRecoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminRecoveryModal: React.FC<AdminRecoveryModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { settings, resetAdminPinWithRecovery } = useStore();

  const [activeTab, setActiveTab] = useState<'master_key' | 'security_question' | 'contact_owner'>('master_key');
  
  // Recovery input fields
  const [masterKeyInput, setMasterKeyInput] = useState('');
  const [securityAnswerInput, setSecurityAnswerInput] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Status states
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [isResetDone, setIsResetDone] = useState(false);

  if (!isOpen) return null;

  const handleResetWithMasterKey = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!masterKeyInput.trim()) {
      setErrorMessage('تکایە کۆدی فریاگوزاری بنووسە.');
      return;
    }

    if (!newPin || newPin.length < 4) {
      setErrorMessage('کۆدی نوێ پێویستە بەلایەنی کەم ٤ ژمارە یان پیت بێت.');
      return;
    }

    if (newPin !== confirmPin) {
      setErrorMessage('کۆدی نوێ و دووپاتکردنەوەکەی لە یەک ناچن!');
      return;
    }

    const result = resetAdminPinWithRecovery(masterKeyInput, newPin);

    if (result.success) {
      setSuccessMessage(result.message);
      setIsResetDone(true);
      setTimeout(() => {
        sessionStorage.setItem('admin_session_unlocked', 'true');
        onSuccess();
      }, 1500);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleResetWithSecurityQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!securityAnswerInput.trim()) {
      setErrorMessage('تکایە وەڵامی پرسیاری ئەمنی بنووسە.');
      return;
    }

    if (!newPin || newPin.length < 4) {
      setErrorMessage('کۆدی نوێ پێویستە بەلایەنی کەم ٤ ژمارە یان پیت بێت.');
      return;
    }

    if (newPin !== confirmPin) {
      setErrorMessage('کۆدی نوێ و دووپاتکردنەوەکەی لە یەک ناچن!');
      return;
    }

    const result = resetAdminPinWithRecovery(securityAnswerInput, newPin);

    if (result.success) {
      setSuccessMessage(result.message);
      setIsResetDone(true);
      setTimeout(() => {
        sessionStorage.setItem('admin_session_unlocked', 'true');
        onSuccess();
      }, 1500);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleSendEmailRequest = () => {
    const email = settings.recoveryEmail || settings.backupEmail || 'wryaomer996@gmail.com';
    const subject = encodeURIComponent('داواکاری گەڕاندنەوەی پاسۆردی ئەدمین - کۆگای مۆبایل');
    const body = encodeURIComponent(
      `سڵاو خاوەنی بەڕێز،\n\nداواکاری گەڕاندنەوەی پین/پاسۆردی ئەدمین کراوە بۆ ئەپی کۆگای شاشە.\nکاتی داواکاری: ${new Date().toLocaleString()}\nناوی فرۆشگا: ${settings.shopName}\n\nتکایە کۆدی فریاگوزاری بەکاربهێنە بۆ چوونەژوورەوە.`
    );
    window.open(`mailto:${email}?subject=${subject}&body=${body}`, '_blank');
  };

  const handleSendWhatsAppRequest = () => {
    const phone = (settings.phone1 || '07508888042').replace(/[^0-9]/g, '');
    const cleanPhone = phone.startsWith('0') ? '964' + phone.substring(1) : phone;
    const msg = encodeURIComponent(
      `سڵاو خاوەنی بەڕێز، پاسۆردی ئەدمینی کۆگا لەبیرکراوە یان دەستکاری کراوە. دەمەوێت بە کۆدی فریاگوزاری کۆدێکی نوێ دابنێمەوە.`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${msg}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-6 animate-in fade-in zoom-in duration-200" dir="rtl">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-indigo-950 text-white p-5 sm:p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>

          <div className="flex items-center gap-3 mb-2">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center shadow-inner">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-400/30">
                بەشی فریاگوزاری و ئەمنی
              </span>
              <h2 className="text-lg sm:text-xl font-black text-white mt-1">
                گەڕاندنەوە و ڕزگارکردنی کۆدی ئەدمین
              </h2>
            </div>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mt-1">
            ئەگەر کۆدی نهێنیت لەدەستچووە، لەبیرت چووە یان کەسێک دەستکاری کردووە؛ لێرە دەتوانیت ڕاستەوخۆ پینی نوێ دابنێیتەوە.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-100 bg-slate-50/70 p-1.5 gap-1.5 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setActiveTab('master_key');
              setErrorMessage('');
            }}
            className={`flex-1 py-2 px-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'master_key'
                ? 'bg-white text-purple-700 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>کۆدی فریاگوزاری (Master Key)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('security_question');
              setErrorMessage('');
            }}
            className={`flex-1 py-2 px-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'security_question'
                ? 'bg-white text-purple-700 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>پرسیاری ئەمنی</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('contact_owner');
              setErrorMessage('');
            }}
            className={`flex-1 py-2 px-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'contact_owner'
                ? 'bg-white text-purple-700 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>ئیمەیڵ و پەیوەندی</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4">
          {/* Success Banner */}
          {successMessage && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 text-emerald-800 text-xs font-bold animate-in fade-in duration-200">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <p className="text-sm font-black">{successMessage}</p>
                <p className="text-[11px] text-emerald-700 font-normal mt-0.5">
                  دەستبەجێ ئەپەکە ڕەوانەی داشبۆردی بەڕێوەبەرایەتی دەکرێت...
                </p>
              </div>
            </div>
          )}

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2.5 text-rose-700 text-xs font-bold animate-in shake duration-200">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* TAB 1: MASTER RECOVERY KEY */}
          {activeTab === 'master_key' && !isResetDone && (
            <form onSubmit={handleResetWithMasterKey} className="space-y-3.5">
              <div className="bg-purple-50/60 p-3.5 rounded-2xl border border-purple-100 text-xs text-purple-900 space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span>کۆدی فریاگوزاری خاوەنی سەرەکی بنووسە:</span>
                </p>
                <p className="text-[11px] text-purple-700 font-normal">
                  کۆدی پێشوەختەی فریاگوزاری بریتییە لە <code className="font-mono font-bold bg-white px-1.5 py-0.5 rounded border border-purple-200">HAWTA-996-SECURE</code> یان ئەو کۆدە تایبەتەی پێشتر لە ڕێکخستنەکان داتناوە.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  کۆدی فریاگوزاری سەرەکی (Master Emergency Key):
                </label>
                <input
                  type="text"
                  dir="ltr"
                  required
                  value={masterKeyInput}
                  onChange={(e) => setMasterKeyInput(e.target.value)}
                  placeholder="بۆ نموونە: HAWTA-996-SECURE"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-slate-900 focus:bg-white focus:outline-purple-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    کۆدی نوێی ئەدمین (New PIN):
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      dir="ltr"
                      value={newPin}
                      onChange={(e) => setNewPin(e.target.value)}
                      placeholder="٤ ژمارە یان زیاتر..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-slate-900 focus:bg-white focus:outline-purple-600"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    دووپاتکردنەوەی کۆدی نوێ:
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    dir="ltr"
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    placeholder="دووبارەی بکەرەوە..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-slate-900 focus:bg-white focus:outline-purple-600"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition cursor-pointer"
                >
                  پاشگەزبوونەوە
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black shadow-md transition flex items-center gap-1.5 cursor-pointer"
                >
                  <span>گەڕاندنەوە و پاشەکەوتکردنی کۆدی نوێ</span>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </form>
          )}

          {/* TAB 2: SECURITY QUESTION */}
          {activeTab === 'security_question' && !isResetDone && (
            <form onSubmit={handleResetWithSecurityQuestion} className="space-y-3.5">
              <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200/60 text-xs text-amber-900 space-y-1.5">
                <span className="font-bold block text-amber-950">پرسیاری ئەمنی دیاریکراو:</span>
                <p className="font-bold text-sm text-purple-900 bg-white/90 p-2.5 rounded-xl border border-amber-200">
                  {settings.securityQuestion || 'ئیمەیڵی سەرەکی خاوەن فرۆشگا چییە؟'}
                </p>
                <p className="text-[11px] text-amber-700">
                  تەنها وەڵامی ڕاستی خاوەن فرۆشگا دەتوانێت کۆدی نوێ دابنێت.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  وەڵامی پرسیاری ئەمنی:
                </label>
                <input
                  type="text"
                  required
                  value={securityAnswerInput}
                  onChange={(e) => setSecurityAnswerInput(e.target.value)}
                  placeholder="وەڵامەکەت بنووسە (بۆ نموونە: wryaomer996@gmail.com)..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-bold text-slate-900 focus:bg-white focus:outline-purple-600"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    کۆدی نوێی ئەدمین (New PIN):
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    dir="ltr"
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="٤ ژمارە یان زیاتر..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-slate-900 focus:bg-white focus:outline-purple-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    دووپاتکردنەوەی کۆدی نوێ:
                  </label>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    dir="ltr"
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                    placeholder="دووبارەی بکەرەوە..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-slate-900 focus:bg-white focus:outline-purple-600"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition cursor-pointer"
                >
                  پاشگەزبوونەوە
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-black shadow-md transition flex items-center gap-1.5 cursor-pointer"
                >
                  <span>سەلماندن و دانانی کۆدی نوێ</span>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </form>
          )}

          {/* TAB 3: CONTACT OWNER VIA EMAIL / WHATSAPP */}
          {activeTab === 'contact_owner' && (
            <div className="space-y-4 text-xs">
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <p className="font-bold text-slate-800 text-sm">
                  پەیوەندیکردنی ڕاستەوخۆ بە خاوەنی فرۆشگا
                </p>
                <p className="text-slate-500 leading-relaxed">
                  ئەگەر کۆدی فریاگوزاریت بیرچووە، دەتوانیت دەستبەجێ بە ئیمەیڵی تۆمارکراو داواکاری بنێریت بۆ ئیمەیڵی خاوەن فرۆشگا تاوەکو بە شێوەیەکی فەرمی کۆدەکەت بۆ بگەڕێنێتەوە:
                </p>
                <div className="font-mono font-bold text-purple-700 bg-white p-2.5 rounded-xl border border-slate-200 flex items-center justify-between">
                  <span>{settings.recoveryEmail || 'wryaomer996@gmail.com'}</span>
                  <span className="text-[10px] text-slate-400 font-sans">ئیمەیڵی خاوەن</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={handleSendEmailRequest}
                  className="p-3.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-2xl flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <Mail className="w-4 h-4" />
                  <span>ناردنی داواکاری بە ئیمەیڵ</span>
                </button>

                <button
                  type="button"
                  onClick={handleSendWhatsAppRequest}
                  className="p-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <Phone className="w-4 h-4" />
                  <span>ناردنی داواکاری بە وەتسئەپ</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
