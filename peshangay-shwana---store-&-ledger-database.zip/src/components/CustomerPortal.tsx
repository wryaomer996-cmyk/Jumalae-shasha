import React, { useState, useEffect, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { Customer, Invoice, ProductItem } from '../types';
import { InvoiceReceiptModal } from './InvoiceReceiptModal';
import { QuickScreenSearch } from './QuickScreenSearch';
import { AdminRecoveryModal } from './AdminRecoveryModal';
import { 
  Lock, 
  User, 
  Phone, 
  MapPin, 
  Receipt, 
  LogOut, 
  Eye, 
  Printer, 
  FileText, 
  ShieldCheck, 
  CheckCircle,
  Smartphone,
  Search,
  DollarSign,
  AlertCircle,
  MessageCircle,
  KeyRound,
  RefreshCw,
  Calendar,
  Layers,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface CustomerPortalProps {
  selectedCustomerId?: number;
  onSwitchToAdmin?: () => void;
}

export const CustomerPortal: React.FC<CustomerPortalProps> = ({
  selectedCustomerId,
  onSwitchToAdmin,
}) => {
  const { 
    customers, 
    invoices, 
    products, 
    settings, 
    getCustomerStats, 
    verifyAdminPin, 
    findCustomerByCode 
  } = useStore();

  // Active technician currently authenticated
  const [activeTechnician, setActiveTechnician] = useState<Customer | null>(null);
  const [codeInput, setCodeInput] = useState('');
  const [codeError, setCodeError] = useState(false);
  const [selectedInvoiceForView, setSelectedInvoiceForView] = useState<Invoice | null>(null);

  // Active subtab inside technician portal: 'invoices' or 'screens'
  const [activeTab, setActiveTab] = useState<'invoices' | 'screens'>('invoices');

  // Active view on public front page (before technician login): 'screens' (live read-only catalog) or 'login' (passcode card)
  const [frontTab, setFrontTab] = useState<'screens' | 'login'>('screens');

  // Screen Search state
  const [screenSearch, setScreenSearch] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [selectedQuality, setSelectedQuality] = useState<string>('all');

  // Admin PIN Unlock Modal State
  const [showAdminPinModal, setShowAdminPinModal] = useState(false);
  const [adminPinInput, setAdminPinInput] = useState('');
  const [adminPinError, setAdminPinError] = useState(false);
  const [showRecoveryModal, setShowRecoveryModal] = useState(false);

  // 1. Initial Authentication check (URL params or saved session or selectedCustomerId prop)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const codeParam = params.get('code') || params.get('passcode');
    const customerIdParam = params.get('customer_id');

    // Case A: Direct URL passcode (e.g. ?code=262 or ?code=315)
    if (codeParam) {
      const found = findCustomerByCode(codeParam);
      if (found) {
        setActiveTechnician(found);
        localStorage.setItem('portal_active_technician_id', found.id.toString());
        return;
      }
    }

    // Case B: URL has customer_id and matching code
    if (customerIdParam && codeParam) {
      const found = customers.find((c) => c.id === Number(customerIdParam));
      if (found && found.passcode === codeParam) {
        setActiveTechnician(found);
        localStorage.setItem('portal_active_technician_id', found.id.toString());
        return;
      }
    }

    // Case C: Coming directly from Admin dashboard with selectedCustomerId
    if (selectedCustomerId) {
      const found = customers.find((c) => c.id === selectedCustomerId);
      if (found) {
        setActiveTechnician(found);
        localStorage.setItem('portal_active_technician_id', found.id.toString());
        return;
      }
    }

    // Case D: Check saved session in localStorage (only if valid)
    const savedId = localStorage.getItem('portal_active_technician_id') || localStorage.getItem('hawta_active_technician_id');
    if (savedId) {
      const found = customers.find((c) => c.id === Number(savedId));
      if (found) {
        setActiveTechnician(found);
        return;
      }
    }

    // Default: Clean login screen (no pre-selected technician)
    setActiveTechnician(null);
  }, [customers, selectedCustomerId, findCustomerByCode]);

  // Handle Technician Code Submission
  const handleVerifyPasscode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!codeInput.trim()) return;

    const matched = findCustomerByCode(codeInput.trim());

    if (matched) {
      setActiveTechnician(matched);
      setCodeError(false);
      localStorage.setItem('portal_active_technician_id', matched.id.toString());
      setCodeInput('');
    } else {
      setCodeError(true);
    }
  };

  // Handle Logout
  const handleLogout = () => {
    localStorage.removeItem('portal_active_technician_id');
    localStorage.removeItem('hawta_active_technician_id');
    setActiveTechnician(null);
    setCodeInput('');
    setCodeError(false);
    // Clear URL parameters if any
    if (window.location.search) {
      window.history.replaceState({}, '', window.location.pathname);
    }
  };

  // Handle Admin Unlock
  const handleAdminUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (verifyAdminPin(adminPinInput)) {
      setShowAdminPinModal(false);
      setAdminPinInput('');
      setAdminPinError(false);
      if (onSwitchToAdmin) {
        onSwitchToAdmin();
      }
    } else {
      setAdminPinError(true);
    }
  };

  // Filter wholesale screens catalog (READ ONLY for technicians)
  const screensList = useMemo(() => {
    return products.filter((p) => {
      const isScreen = p.category === 'screen' || p.name.includes('شاشە');
      if (!isScreen) return false;

      const matchesSearch =
        p.name.toLowerCase().includes(screenSearch.toLowerCase()) ||
        (p.screenModel && p.screenModel.toLowerCase().includes(screenSearch.toLowerCase())) ||
        p.brand.toLowerCase().includes(screenSearch.toLowerCase());

      const matchesBrand = selectedBrand === 'all' || p.brand.toLowerCase() === selectedBrand.toLowerCase();
      const matchesQuality = selectedQuality === 'all' || p.screenQuality === selectedQuality;

      return matchesSearch && matchesBrand && matchesQuality;
    });
  }, [products, screenSearch, selectedBrand, selectedQuality]);

  const cleanPhone = settings.phone1.replace(/[^0-9]/g, '');
  const whatsAppPhone = cleanPhone.startsWith('0') ? '964' + cleanPhone.slice(1) : cleanPhone;

  // =========================================================================
  // VIEW 1: CLEAN TECHNICIAN LOGIN SCREEN (NEUTRAL, SECURE, NO DEMO CHIPS)
  // Each technician must enter their unique code or registered phone number
  // =========================================================================
  if (!activeTechnician) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
        {/* Top Public Header */}
        <header className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 px-4 py-3 shadow-md">
          <div className="max-w-7xl w-full mx-auto flex flex-wrap items-center justify-between gap-3">
            {/* Logo & Brand */}
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-500/20">
                <Smartphone className="w-6 h-6" />
              </div>
              <div>
                <div className="font-black text-slate-100 text-sm sm:text-base leading-tight">
                  {settings.shopName}
                </div>
                <div className="text-[11px] font-bold text-purple-400">
                  {settings.subTitle || 'فرۆشتنی جوملەی شاشە و پارچەی مۆبایل'}
                </div>
              </div>
            </div>

            {/* Middle Live Exchange Rate */}
            <div className="hidden sm:flex items-center gap-2 bg-slate-800/90 border border-slate-700/80 px-3 py-1.5 rounded-xl text-xs font-mono">
              <span className="text-slate-400 font-medium">نرخی بۆرسە 100$ =</span>
              <span className="font-black text-emerald-400">
                {(settings.usdToIqdRate || 152000).toLocaleString()} د.ع
              </span>
            </div>

            {/* Right Action buttons */}
            <div className="flex items-center gap-2">
              {/* WhatsApp direct chat */}
              <a
                href={`https://wa.me/${whatsAppPhone}?text=${encodeURIComponent(`سڵاو کاک ${settings.ownerName || 'بەڕێز'}، سەبارەت بە نرخی شاشەی جوملە پرسیارم هەبوو...`)}`}
                target="_blank"
                rel="noreferrer"
                className="hidden md:flex items-center gap-1.5 px-3 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 rounded-xl text-xs font-bold border border-emerald-500/30 transition"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>پەیوەندی بە وەتسئەپ</span>
              </a>

              {/* Admin Unlock Button */}
              <button
                onClick={() => {
                  setAdminPinInput('');
                  setAdminPinError(false);
                  setShowAdminPinModal(true);
                }}
                className="px-3.5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-purple-900/30 cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>چوونەژوورەوەی ئەدمین</span>
              </button>
            </div>
          </div>
        </header>

        {/* Hero & Navigation Switcher */}
        <div className="bg-gradient-to-b from-slate-900 via-slate-850 to-slate-900 border-b border-slate-800/80 px-4 pt-6 pb-6">
          <div className="max-w-4xl mx-auto text-center space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-800/60 text-purple-300 text-xs font-bold shadow-inner">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>پەڕەی سەرەکی و پۆرتاڵی وەستاکان</span>
            </div>
            
            <h1 className="text-xl sm:text-3xl font-black text-white tracking-tight">
              پۆرتاڵی جوملەی شاشە و حیساباتی وەستاکان
            </h1>
            
            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl mx-auto leading-relaxed">
              ڕاستەوخۆ نرخ و بەردەستبوونی شاشەکان بە نوێکراوەیی ببینە (Read-Only)، یان بە کۆدی تایبەتی خۆت بچۆ ژوورەوە بۆ پشکنینی قەرز و وەسڵەکانت.
            </p>

            {/* Segmented Mode Selector */}
            <div className="pt-2 flex items-center justify-center">
              <div className="bg-slate-850 p-1.5 rounded-2xl border border-slate-700/80 flex items-center gap-1 shadow-lg max-w-md w-full">
                <button
                  type="button"
                  onClick={() => setFrontTab('screens')}
                  className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
                    frontTab === 'screens'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Search className="w-4 h-4" />
                  <span>گەڕانی شاشەکان (Read-Only)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setFrontTab('login')}
                  className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition flex items-center justify-center gap-2 cursor-pointer ${
                    frontTab === 'login'
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <KeyRound className="w-4 h-4" />
                  <span>هەژماری وەستا (کۆد)</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Area based on frontTab */}
        <div className="flex-1 p-3 sm:p-6 max-w-7xl w-full mx-auto">
          {frontTab === 'screens' ? (
            <div className="space-y-4">
              {/* Informative Banner */}
              <div className="bg-slate-850 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-slate-300 font-bold">
                    نرخەکانی ئەم بەشە ڕاستەوخۆیە بۆ هەموو وەستاکان و کڕیاران (خوێندنەوە / Read-Only).
                  </span>
                </div>

                <button
                  onClick={() => setFrontTab('login')}
                  className="text-purple-400 hover:text-purple-300 font-black inline-flex items-center gap-1 cursor-pointer"
                >
                  <span>چوونەژوورەوە بۆ بینینی قەرزی ماوەت بە کۆد</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* QuickScreenSearch rendered in full page, completely read-only */}
              <QuickScreenSearch fullPage readOnly />
            </div>
          ) : (
            /* Front Page Login Card */
            <div className="max-w-md w-full mx-auto my-8 bg-white text-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
              <div className="text-center mb-6">
                <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-tr from-purple-600 to-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-purple-500/30">
                  <KeyRound className="w-8 h-8" />
                </div>
                <h2 className="text-2xl font-black text-slate-900">چوونەژوورەوەی وەستا</h2>
                <p className="text-xs font-bold text-purple-700 mt-1">{settings.shopName}</p>
                <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                  تکایە کۆدی نهێنی تایبەتی خۆت یان ژمارەی مۆبایلەکەت بنووسە بۆ بینینی قەرزی ماوە، وەسڵەکان و مێژووی کڕینەکانت:
                </p>
              </div>

              {/* Passcode Form */}
              <form onSubmit={handleVerifyPasscode} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    کۆدی نهێنی یان ژمارەی مۆبایل:
                  </label>
                  <div className="relative">
                    <input
                      type="password"
                      inputMode="numeric"
                      autoFocus
                      required
                      value={codeInput}
                      onChange={(e) => {
                        setCodeInput(e.target.value);
                        setCodeError(false);
                      }}
                      placeholder="کۆدی نهێنی..."
                      className="w-full text-center text-2xl font-mono tracking-widest py-3 px-4 bg-slate-50 border-2 border-purple-200 rounded-2xl focus:outline-none focus:border-purple-600 font-black text-slate-800 shadow-inner"
                      maxLength={11}
                    />
                  </div>

                  {codeError && (
                    <div className="mt-2.5 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 font-bold flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                      <span>
                        ئەم کۆدە هەڵەیە یان تۆمار نەکراوە! تکایە کۆدی دروست بنووسە.
                      </span>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-2xl shadow-lg hover:shadow-xl hover:from-purple-700 hover:to-indigo-700 transition flex items-center justify-center gap-2 text-sm cursor-pointer"
                >
                  <CheckCircle className="w-5 h-5" />
                  <span>چوونەژوورەوەی هەژمار</span>
                </button>
              </form>

              {/* Back to screens catalog shortcut */}
              <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => setFrontTab('screens')}
                  className="text-purple-600 hover:text-purple-800 font-bold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>گەڕانەوە بۆ لیستی نرخ و شاشەکان</span>
                </button>

                <a
                  href={`https://wa.me/${whatsAppPhone}?text=${encodeURIComponent(`سڵاو کاک ${settings.ownerName || 'بەڕێز'}، کۆدی پۆرتاڵی وەستاکانم بیرچووە...`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-slate-500 hover:text-purple-600 font-medium"
                >
                  کۆدت بیرچووە؟
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <footer className="mt-auto border-t border-slate-800/80 py-4 px-4 text-center text-xs text-slate-500">
          <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <span>{settings.shopName} • {settings.address}</span>
            <span className="font-mono text-slate-400">تەلەفۆن: {settings.phone1}</span>
          </div>
        </footer>

        {/* Admin PIN Unlock Modal */}
        {showAdminPinModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
            <div className="w-full max-w-sm bg-white text-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200 text-center animate-in fade-in zoom-in duration-200">
              <div className="w-12 h-12 mx-auto mb-3 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black text-slate-900 mb-1">چوونەژوورەوەی ئەدمین</h3>
              <p className="text-xs text-slate-500 mb-4">
                تایبەت بە بەڕێوەبەر. تکایە پینی نهێنی (PIN) بنووسە:
              </p>

              <form onSubmit={handleAdminUnlock} className="space-y-3">
                <input
                  type="password"
                  inputMode="numeric"
                  autoFocus
                  value={adminPinInput}
                  onChange={(e) => {
                    setAdminPinInput(e.target.value);
                    setAdminPinError(false);
                  }}
                  placeholder="کۆدی نهێنی..."
                  className="w-full text-center text-xl font-mono tracking-widest py-2.5 px-3 bg-slate-50 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-purple-600 font-bold text-slate-900"
                />

                {adminPinError && (
                  <p className="text-xs text-rose-600 font-bold">کۆدی ئەدمین هەڵەیە! تکایە پینی دروست بنووسە.</p>
                )}

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAdminPinModal(false)}
                    className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
                  >
                    پاشگەزبوونەوە
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
                  >
                    چوونەژوورەوە
                  </button>
                </div>

                <div className="pt-2.5 mt-2 border-t border-slate-100 text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAdminPinModal(false);
                      setShowRecoveryModal(true);
                    }}
                    className="text-[11px] text-purple-700 hover:text-purple-900 font-bold flex items-center justify-center gap-1.5 mx-auto transition cursor-pointer hover:underline"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                    <span>کۆدی ئەدمینت لەدەستچووە یان براوە؟ ڕزگارکردنی پین</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  // =========================================================================
  // VIEW 2: AUTHENTICATED TECHNICIAN PORTAL
  // Strictly shows this specific technician's invoices, debts, and screen search
  // Fully responsive across Mobile, Tablet, and Desktop (PC)
  // =========================================================================
  const stats = getCustomerStats(activeTechnician.id);
  const customerInvoices = invoices.filter((i) => i.customerId === activeTechnician.id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 pb-20 text-slate-100 font-sans">
      {/* Top Header */}
      <div className="no-print bg-white/95 text-slate-800 py-3.5 px-4 rounded-b-3xl shadow-xl backdrop-blur-md mb-4 sm:mb-6 border-b border-slate-200">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          {/* Admin Lock / Switcher */}
          <button
            onClick={() => {
              setAdminPinInput('');
              setAdminPinError(false);
              setShowAdminPinModal(true);
            }}
            title="چوونەژوورەوەی بەڕێوەبەر"
            className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:text-purple-700 bg-slate-100 hover:bg-purple-50 rounded-xl transition flex items-center gap-1.5 border border-slate-200 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-purple-600" />
            <span>ئەدمین</span>
          </button>

          {/* Shop Title Center */}
          <div className="text-center">
            <h1 className="text-base sm:text-lg font-black text-purple-700 leading-tight">{settings.shopName}</h1>
            <p className="text-[10px] sm:text-[11px] font-semibold text-slate-500">
              {settings.subTitle}
            </p>
          </div>

          {/* Logout / Switch Technician */}
          <button
            onClick={handleLogout}
            title="دەرچوون لەم هەژمارە و گۆڕینی کۆد"
            className="px-3 py-1.5 text-xs font-bold text-rose-600 hover:text-white bg-rose-50 hover:bg-rose-600 rounded-xl transition flex items-center gap-1.5 border border-rose-200 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">دەرچوون</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-5xl mx-auto px-3 sm:px-6 space-y-4 sm:space-y-6">
        {/* Technician Profile Card */}
        <div className="bg-white text-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl border-r-6 sm:border-r-8 border-purple-600">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-lg shadow-inner shrink-0">
                <User className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-lg sm:text-xl font-black text-slate-900">{activeTechnician.name}</h2>
                  <span className="text-[11px] sm:text-xs font-mono bg-purple-100 text-purple-800 px-2.5 py-0.5 rounded-lg font-bold">
                    کۆدی نهێنی: {activeTechnician.passcode}
                  </span>
                </div>
                <p className="text-[11px] sm:text-xs text-slate-500 mt-0.5">
                  پۆرتاڵی تایبەت بە وەستا • حیسابات و نرخی شاشە
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <a
                href={`https://wa.me/${whatsAppPhone}?text=${encodeURIComponent(`سڵاو کاک ${settings.ownerName}، لەسەر حیسابی وەستا ${activeTechnician.name} پەیوەندیم کرد...`)}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white font-bold text-xs rounded-xl border border-emerald-200 transition shadow-xs"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>پەیوەندی بە وەتسئەپ</span>
              </a>

              <button
                onClick={handleLogout}
                className="flex items-center gap-1 px-3 py-2 bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 font-semibold text-xs rounded-xl border border-slate-200 transition cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">گۆڕینی کۆد</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="bg-slate-50 p-2.5 sm:p-3 rounded-xl border border-slate-100 flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-purple-600 shrink-0" />
              <div>
                <span className="text-slate-400 text-[10px] block">ژمارەی مۆبایل:</span>
                <span className="font-bold text-slate-800 font-mono" dir="ltr">{activeTechnician.phone}</span>
              </div>
            </div>

            <div className="bg-slate-50 p-2.5 sm:p-3 rounded-xl border border-slate-100 flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-purple-600 shrink-0" />
              <div>
                <span className="text-slate-400 text-[10px] block">شوێن / ناونیشان:</span>
                <span className="font-bold text-slate-800">{activeTechnician.address || 'حاجیاوا'}</span>
              </div>
            </div>

            <div className="bg-slate-50 p-2.5 sm:p-3 rounded-xl border border-slate-100 flex items-center gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <span className="text-slate-400 text-[10px] block">دۆخی هەژمار:</span>
                <span className="font-bold text-emerald-700">پارێزراو • هەژماری کەسی وەستا</span>
              </div>
            </div>
          </div>
        </div>

        {/* Financial Summary Cards - "CHANDAY LASARA" */}
        <div className="bg-white text-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl">
          <div className="flex items-center justify-between mb-3 sm:mb-4">
            <h3 className="text-sm sm:text-base font-bold text-slate-800 flex items-center gap-2">
              <Receipt className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600" />
              <span>پوختەی دارایی و قەرزی ماوەتەوە لەسەر تۆ:</span>
            </h3>
            <button
              onClick={() => window.print()}
              className="no-print flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-xl transition cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">چاپکردنی وەسڵەکان</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
            {/* Prominent Outstanding Debt */}
            <div className={`p-4 rounded-2xl text-center border-2 shadow-sm ${
              stats.totalDebt > 0 
                ? 'bg-rose-50 border-rose-300 text-rose-900' 
                : 'bg-emerald-50 border-emerald-300 text-emerald-900'
            }`}>
              <span className="text-xs font-bold block mb-1">
                {stats.totalDebt > 0 ? 'قەرزی ماوەی سەر تۆ (پێویستە بدرێت)' : 'قەرزی سەر تۆ'}
              </span>
              <span className="text-2xl md:text-3xl font-black font-mono block">
                {stats.totalDebt.toLocaleString()}
              </span>
              <span className="text-xs font-bold block mt-1">
                {stats.totalDebt > 0 ? 'دیناری عێراقی دەمێنێتەوە' : 'حیساب پاکراوەتەوە - هیچ قەرزت لەسەر نییە'}
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 p-3 sm:p-4 rounded-2xl text-center">
              <span className="text-xs font-semibold text-slate-500 block mb-0.5">کۆی کڕینەکان (وەسڵەکان)</span>
              <span className="text-base sm:text-lg md:text-xl font-black text-slate-800 font-mono">
                {stats.totalInvoicesAmount.toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">دیناری عێراقی</span>
            </div>

            <div className="bg-emerald-50/70 border border-emerald-200 p-3 sm:p-4 rounded-2xl text-center">
              <span className="text-xs font-semibold text-emerald-700 block mb-0.5">پارەی دراو بە کاش</span>
              <span className="text-base sm:text-lg md:text-xl font-black text-emerald-700 font-mono">
                {stats.totalPaidAmount.toLocaleString()}
              </span>
              <span className="text-[10px] text-emerald-600 block mt-0.5">دراوە بە کاش</span>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 p-3 sm:p-4 rounded-2xl text-center">
              <span className="text-xs font-semibold text-slate-500 block mb-0.5">داشکاندن</span>
              <span className="text-base sm:text-lg md:text-xl font-black text-slate-700 font-mono">
                {stats.totalDiscount.toLocaleString()}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">دینار داشکێنراوە</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs between Invoices and Wholesale Screen Catalog */}
        <div className="flex items-center gap-2 bg-white/10 p-1.5 rounded-2xl backdrop-blur-md border border-white/10">
          <button
            onClick={() => setActiveTab('invoices')}
            className={`flex-1 py-2.5 sm:py-3 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition cursor-pointer ${
              activeTab === 'invoices'
                ? 'bg-purple-600 text-white shadow-lg'
                : 'text-purple-200 hover:text-white hover:bg-white/5'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>وەسڵەکانی من ({customerInvoices.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('screens')}
            className={`flex-1 py-2.5 sm:py-3 px-3 sm:px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 sm:gap-2 transition cursor-pointer ${
              activeTab === 'screens'
                ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                : 'text-purple-200 hover:text-white hover:bg-white/5'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>گەڕان بەدوای شاشە و نرخ 🔍</span>
          </button>
        </div>

        {/* TAB 1: INVOICES LIST (STRICTLY FOR THIS SPECIFIC TECHNICIAN) */}
        {activeTab === 'invoices' && (
          <div className="bg-white text-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm sm:text-base font-bold text-slate-800 flex items-center gap-2">
                <FileText className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600" />
                <span>لیستی وەسڵەکان ({customerInvoices.length})</span>
              </h3>
              <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
                تەنها بۆ بینین و چاپکردن (Read-Only)
              </span>
            </div>

            {customerInvoices.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm font-medium bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                هیچ وەسڵێک بۆ هەژمارەکەت تۆمار نەکراوە
              </div>
            ) : (
              <>
                {/* Mobile Card View (< sm:) */}
                <div className="sm:hidden space-y-3">
                  {customerInvoices.map((inv) => (
                    <div
                      key={inv.id}
                      className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2.5 hover:border-purple-300 transition"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-black text-purple-700 text-sm">
                          وەسڵ #{inv.id}
                        </span>
                        <span className="text-[11px] text-slate-500 font-mono" dir="ltr">
                          {inv.date}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 bg-white p-2.5 rounded-xl border border-slate-100 text-xs">
                        <div>
                          <span className="text-slate-400 text-[10px] block">کۆی وەسڵ:</span>
                          <span className="font-mono font-bold text-slate-900">
                            {inv.totalAmount.toLocaleString()} دینار
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 text-[10px] block">قەرزی ماوە:</span>
                          <span className="font-mono font-black text-rose-600">
                            {inv.remainingDebt.toLocaleString()} دینار
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => setSelectedInvoiceForView(inv)}
                        className="w-full py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>بینین و پسوولەی چاپ</span>
                      </button>
                    </div>
                  ))}
                </div>

                {/* Desktop & Tablet Table View (>= sm:) */}
                <div className="hidden sm:block overflow-x-auto">
                  <table className="w-full text-right text-xs sm:text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/70">
                        <th className="py-3 px-3">ژمارەی وەسڵ</th>
                        <th className="py-3 px-3">بەروار و کات</th>
                        <th className="py-3 px-3">جۆر</th>
                        <th className="py-3 px-3 text-left">کۆی وەسڵ</th>
                        <th className="py-3 px-3 text-left">بڕی دراو</th>
                        <th className="py-3 px-3 text-left">داشکاندن</th>
                        <th className="py-3 px-3 text-left">قەرز</th>
                        <th className="py-3 px-3 text-center">پسوولە</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {customerInvoices.map((inv) => (
                        <tr key={inv.id} className="hover:bg-purple-50/40 transition">
                          <td className="py-3 px-3 font-mono font-bold text-purple-700">
                            #{inv.id}
                          </td>
                          <td className="py-3 px-3 text-slate-600 text-xs font-mono" dir="ltr">
                            {inv.date}
                          </td>
                          <td className="py-3 px-3">
                            <span className="inline-block px-2 py-0.5 rounded-md text-xs font-bold bg-purple-50 text-purple-700">
                              {inv.type === 'Wholesale' ? 'جوملە' : inv.type}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-left font-mono font-bold text-slate-900">
                            {inv.totalAmount.toLocaleString()} دینار
                          </td>
                          <td className="py-3 px-3 text-left font-mono text-emerald-600 font-bold">
                            {inv.paidAmount.toLocaleString()} دینار
                          </td>
                          <td className="py-3 px-3 text-left font-mono text-slate-500">
                            {inv.discount.toLocaleString()} دینار
                          </td>
                          <td className="py-3 px-3 text-left font-mono font-extrabold text-rose-600">
                            {inv.remainingDebt.toLocaleString()} دینار
                          </td>
                          <td className="py-3 px-3 text-center">
                            <button
                              onClick={() => setSelectedInvoiceForView(inv)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 bg-purple-50 text-purple-700 hover:bg-purple-600 hover:text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>بینین</span>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}

        {/* TAB 2: DEDICATED WHOLESALE SCREEN SEARCH & PRICES */}
        {activeTab === 'screens' && (
          <div className="bg-white text-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl space-y-4 sm:space-y-6">
            <div className="border-b border-slate-100 pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div>
                  <h3 className="text-lg sm:text-xl font-black text-purple-800 flex items-center gap-2">
                    <Smartphone className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
                    <span>گەڕان بەدوای شاشە و نرخی جوملە</span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    ڕاستەوخۆ بەدوای مۆدێلی شاشە بگەڕێ و نرخ و کواڵیتی ببینە
                  </p>
                </div>

                <div className="bg-purple-50 border border-purple-200 px-3 py-1.5 rounded-xl text-xs font-bold text-purple-800 flex items-center gap-1.5 self-start sm:self-auto">
                  <DollarSign className="w-4 h-4 text-emerald-600" />
                  <span>100$ = {(settings.usdToIqdRate || 152000).toLocaleString()} د.ع</span>
                </div>
              </div>

              {/* Search Bar Input */}
              <div className="mt-3.5 relative">
                <Search className="w-5 h-5 text-slate-400 absolute right-3.5 top-3.5" />
                <input
                  type="text"
                  value={screenSearch}
                  onChange={(e) => setScreenSearch(e.target.value)}
                  placeholder="ناوی مۆدێلی شاشە بنووسە... (iPhone, A54, Note 12, OLED...)"
                  className="w-full bg-slate-50 border-2 border-purple-200 rounded-2xl pr-11 pl-10 py-3 text-xs sm:text-sm font-bold focus:outline-none focus:border-purple-600 shadow-inner"
                />
                {screenSearch && (
                  <button
                    onClick={() => setScreenSearch('')}
                    className="absolute left-3 top-3.5 text-slate-400 hover:text-slate-600 text-xs font-bold bg-slate-200 rounded-full w-5 h-5 flex items-center justify-center cursor-pointer"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Filter Pills with Horizontal Scroll on Mobile */}
              <div className="mt-3 overflow-x-auto pb-1 flex items-center gap-1.5 text-xs whitespace-nowrap">
                <span className="text-slate-400 font-bold ml-1 text-[11px]">براند:</span>
                {['all', 'Apple', 'Samsung', 'Xiaomi', 'Honor'].map((b) => (
                  <button
                    key={b}
                    onClick={() => setSelectedBrand(b)}
                    className={`px-3 py-1 rounded-xl font-bold transition cursor-pointer shrink-0 ${
                      selectedBrand === b
                        ? 'bg-purple-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {b === 'all' ? 'هەموو' : b}
                  </button>
                ))}

                <span className="text-slate-400 font-bold ml-1 mr-2 text-[11px]">کواڵیتی:</span>
                {[
                  { id: 'all', label: 'هەموو' },
                  { id: 'Original Service Pack', label: 'ئەسڵی' },
                  { id: 'OLED', label: 'OLED' },
                  { id: 'Incell', label: 'Incell' },
                ].map((q) => (
                  <button
                    key={q.id}
                    onClick={() => setSelectedQuality(q.id)}
                    className={`px-3 py-1 rounded-xl font-bold transition cursor-pointer shrink-0 ${
                      selectedQuality === q.id
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {q.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Results Grid: 1 col on Mobile, 2 on Tablet, 3 on Desktop */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              {screensList.map((screen) => {
                const usdPrice = (screen.sellPrice / ((settings.usdToIqdRate || 152000) / 100)).toFixed(1);
                const isOutOfStock = screen.quantity <= 0;

                return (
                  <div
                    key={screen.id}
                    className="bg-slate-50 border border-slate-200/90 rounded-2xl p-3.5 sm:p-4 flex flex-col justify-between hover:border-purple-300 hover:shadow-md transition"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="text-xs font-bold text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                          {screen.brand}
                        </span>

                        {screen.screenQuality && (
                          <span className={`text-[11px] px-2 py-0.5 rounded-md font-bold ${
                            screen.screenQuality.includes('Original')
                              ? 'bg-amber-100 text-amber-800 border border-amber-200'
                              : screen.screenQuality === 'OLED'
                              ? 'bg-purple-100 text-purple-800 border border-purple-200'
                              : 'bg-blue-100 text-blue-800 border border-blue-200'
                          }`}>
                            {screen.screenQuality}
                          </span>
                        )}
                      </div>

                      <h4 className="font-bold text-slate-900 text-sm mb-1 leading-snug">
                        {screen.name}
                      </h4>

                      {screen.screenModel && (
                        <p className="text-xs text-slate-500 font-mono mb-2">
                          مۆدێل: {screen.screenModel}
                        </p>
                      )}
                    </div>

                    <div className="pt-2.5 border-t border-slate-200/70 mt-2">
                      <div className="flex items-baseline justify-between mb-2">
                        <div>
                          <span className="text-[10px] text-slate-400 block">نرخی جوملە:</span>
                          <span className="text-base sm:text-lg font-black text-purple-700 font-mono">
                            {screen.sellPrice.toLocaleString()}
                          </span>
                          <span className="text-[10px] text-slate-500 font-bold mr-1">دینار</span>
                        </div>

                        <div className="text-left">
                          <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200 block">
                            ${usdPrice}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                        <div>
                          {isOutOfStock ? (
                            <span className="text-[11px] font-bold text-rose-600 flex items-center gap-1">
                              <AlertCircle className="w-3.5 h-3.5" />
                              <span>نەماوە لە کۆگا</span>
                            </span>
                          ) : (
                            <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" />
                              <span>مەوجوودە ({screen.quantity})</span>
                            </span>
                          )}
                        </div>

                        <a
                          href={`https://wa.me/${whatsAppPhone}?text=${encodeURIComponent(`سڵاو کاک ${settings.ownerName || 'بەڕێز'}، لەسەر حیسابی وەستا ${activeTechnician.name}، دەمەوێت ئەم شاشەیە داوابکەم:\nناوی شاشە: ${screen.name}\nکواڵیتی: ${screen.screenQuality || 'دیاری نەکراو'}\nنرخ: ${screen.sellPrice.toLocaleString()} دینار`)}`}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-xs"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>داواکردن</span>
                        </a>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {screensList.length === 0 && (
              <div className="py-12 text-center text-slate-400 text-sm font-medium bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                هیچ شاشەیەک بەم مەرجانە نەدۆزرایەوە
              </div>
            )}
          </div>
        )}
      </div>

      {/* Admin Unlock Modal */}
      {showAdminPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-white text-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200 text-center animate-in fade-in zoom-in duration-200">
            <div className="w-12 h-12 mx-auto mb-3 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-1">چوونەژوورەوەی ئەدمین</h3>
            <p className="text-xs text-slate-500 mb-4">
              تایبەت بە بەڕێوەبەر. کۆدی نهێنی بنووسە:
            </p>

            <form onSubmit={handleAdminUnlock} className="space-y-3">
              <input
                type="password"
                inputMode="numeric"
                autoFocus
                value={adminPinInput}
                onChange={(e) => {
                  setAdminPinInput(e.target.value);
                  setAdminPinError(false);
                }}
                placeholder="کۆدی نهێنی..."
                className="w-full text-center text-xl font-mono tracking-widest py-2.5 px-3 bg-slate-50 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-purple-600 font-bold"
              />

              {adminPinError && (
                <p className="text-xs text-rose-600 font-bold">کۆدی ئەدمین هەڵەیە! تکایە کۆدی دروست بنووسە.</p>
              )}

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdminPinModal(false)}
                  className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
                >
                  پاشگەزبوونەوە
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs transition cursor-pointer"
                >
                  چوونەژوورەوە
                </button>
              </div>

              <div className="pt-2.5 mt-2 border-t border-slate-100 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setShowAdminPinModal(false);
                    setShowRecoveryModal(true);
                  }}
                  className="text-[11px] text-purple-700 hover:text-purple-900 font-bold flex items-center justify-center gap-1.5 mx-auto transition cursor-pointer hover:underline"
                >
                  <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                  <span>کۆدی ئەدمینت لەدەستچووە یان براوە؟ ڕزگارکردنی پین</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Admin Recovery Modal */}
      <AdminRecoveryModal
        isOpen={showRecoveryModal}
        onClose={() => setShowRecoveryModal(false)}
        onSuccess={() => {
          setShowRecoveryModal(false);
          if (onSwitchToAdmin) {
            onSwitchToAdmin();
          }
        }}
      />

      {/* Invoice Viewer Modal */}
      {selectedInvoiceForView && (
        <InvoiceReceiptModal
          invoice={selectedInvoiceForView}
          customer={activeTechnician}
          onClose={() => setSelectedInvoiceForView(null)}
        />
      )}
    </div>
  );
};
