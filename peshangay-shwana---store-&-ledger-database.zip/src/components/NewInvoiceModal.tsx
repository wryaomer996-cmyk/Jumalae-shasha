import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Customer, InvoiceItem } from '../types';
import { X, Plus, Trash2, Smartphone, Check, UserPlus, Receipt, Layers } from 'lucide-react';

interface NewInvoiceModalProps {
  onClose: () => void;
  onInvoiceCreated: (invoiceId: number) => void;
  initialCustomerId?: number;
}

export const NewInvoiceModal: React.FC<NewInvoiceModalProps> = ({
  onClose,
  onInvoiceCreated,
  initialCustomerId,
}) => {
  const { customers, products, settings, addInvoice, getCustomerStats, addCustomer } = useStore();

  const [selectedCustomerId, setSelectedCustomerId] = useState<number>(
    initialCustomerId || (customers[0] ? customers[0].id : 0)
  );

  // New quick customer mode
  const [showQuickAddCust, setShowQuickAddCust] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('حاجیاوا');

  const [branch, setBranch] = useState('سەرەکی');
  const [invoiceType, setInvoiceType] = useState<'Wholesale' | 'Sale' | 'Return'>('Wholesale');
  const [items, setItems] = useState<InvoiceItem[]>([
    {
      id: '1',
      name: '',
      price: 0,
      quantity: 1,
      total: 0,
    },
  ]);

  const [discount, setDiscount] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [notes, setNotes] = useState('');

  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);
  const customerStats = selectedCustomerId ? getCustomerStats(selectedCustomerId) : null;
  const previousDebt = customerStats ? customerStats.totalDebt : 0;

  // Auto calculate totals
  const subTotal = items.reduce((sum, item) => sum + item.total, 0);
  const grandTotal = Math.max(0, subTotal - discount);
  const remainingDebt = Math.max(0, previousDebt + grandTotal - paidAmount);

  const handleAddItem = () => {
    setItems((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        name: '',
        price: 0,
        quantity: 1,
        total: 0,
      },
    ]);
  };

  const handleItemSelectFromCatalog = (itemId: string, productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;

    setItems((prev) =>
      prev.map((it) => {
        if (it.id === itemId) {
          const qty = it.quantity || 1;
          return {
            ...it,
            name: prod.name,
            price: prod.sellPrice,
            quantity: qty,
            total: prod.sellPrice * qty,
            quality: prod.screenQuality,
          };
        }
        return it;
      })
    );
  };

  const handleUpdateItem = (itemId: string, field: keyof InvoiceItem, val: any) => {
    setItems((prev) =>
      prev.map((it) => {
        if (it.id === itemId) {
          const updated = { ...it, [field]: val };
          if (field === 'price' || field === 'quantity') {
            updated.total = (Number(updated.price) || 0) * (Number(updated.quantity) || 0);
          }
          return updated;
        }
        return it;
      })
    );
  };

  const handleRemoveItem = (itemId: string) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((it) => it.id !== itemId));
  };

  const handleQuickAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustName.trim() || !newCustPhone.trim()) return;

    const newCust = addCustomer({
      name: newCustName,
      phone: newCustPhone,
      address: newCustAddress,
      passcode: Math.floor(100 + Math.random() * 899).toString(),
      notes: 'وەستای نوێ',
    });

    setSelectedCustomerId(newCust.id);
    setShowQuickAddCust(false);
    setNewCustName('');
    setNewCustPhone('');
  };

  const handleSubmitInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId) {
      alert('تکایە کڕیارێک یان وەستایەک دیاری بکە');
      return;
    }

    const validItems = items.filter((it) => it.name.trim() !== '' && it.price > 0);
    if (validItems.length === 0) {
      alert('تکایە بەلایەنی کەمەوە یەک ماددە یان شاشە بە نرخەوە بنووسە');
      return;
    }

    const newInv = addInvoice({
      customerId: selectedCustomerId,
      branch,
      type: invoiceType,
      items: validItems,
      totalAmount: grandTotal,
      paidAmount: Number(paidAmount) || 0,
      discount: Number(discount) || 0,
      previousDebt,
      remainingDebt,
      currency: 'IQD',
      notes,
    });

    onInvoiceCreated(newInv.id);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden my-6 border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-gradient-to-r from-purple-700 to-indigo-700 text-white">
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-purple-200" />
            <h2 className="text-lg font-bold">دەرکردنی وەسڵی نوێ (پسوولەی جوملە بۆ وەستا)</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-purple-200 hover:text-white rounded-lg hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSubmitInvoice} className="p-6 space-y-6">
          {/* Customer Selection Row */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <label className="text-xs font-bold text-slate-700">وەستا / کڕیار دیاریبکە:</label>
              <button
                type="button"
                onClick={() => setShowQuickAddCust(!showQuickAddCust)}
                className="text-xs text-purple-700 hover:text-purple-900 font-bold flex items-center gap-1 cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{showQuickAddCust ? 'پاشگەزبوونەوە' : 'زیادکردنی وەستای نوێ'}</span>
              </button>
            </div>

            {showQuickAddCust ? (
              <div className="bg-white p-3.5 rounded-xl border border-purple-200 mb-3 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="ناوی وەستا..."
                    value={newCustName}
                    onChange={(e) => setNewCustName(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold focus:outline-purple-600"
                  />
                  <input
                    type="text"
                    dir="ltr"
                    placeholder="مۆبایل (0750...)"
                    value={newCustPhone}
                    onChange={(e) => setNewCustPhone(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold focus:outline-purple-600"
                  />
                  <input
                    type="text"
                    placeholder="ناونیشان..."
                    value={newCustAddress}
                    onChange={(e) => setNewCustAddress(e.target.value)}
                    className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-medium focus:outline-purple-600"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleQuickAddCustomer}
                  className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-lg transition flex items-center gap-1 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>پاشەکەوت و دیاریکردن</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-800 focus:outline-purple-600"
                  >
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone}) - #{c.id}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedCustomer && (
                  <div className="flex items-center justify-between text-xs bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-500 font-medium">قەرزی پێشووی وەستا:</span>
                    <span
                      className={`font-black font-mono text-sm ${
                        previousDebt > 0 ? 'text-rose-600' : 'text-emerald-600'
                      }`}
                    >
                      {previousDebt.toLocaleString()} دینار
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Items / Screens Table */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-purple-600" />
                <span>شاشە و کەلوپەلەکانی ناو وەسڵ:</span>
              </h3>
              <button
                type="button"
                onClick={handleAddItem}
                className="flex items-center gap-1 px-3 py-1 bg-purple-50 text-purple-700 hover:bg-purple-100 font-bold text-xs rounded-lg transition cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>زیادکردنی شاشە / ماددە</span>
              </button>
            </div>

            <div className="border border-slate-200 rounded-2xl overflow-hidden">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-500 border-b border-slate-200">
                    <th className="py-2.5 px-3">دیاریکردن لە کۆگا یان نووسینی ناو</th>
                    <th className="py-2.5 px-2 w-32">نرخی جوملە (دینار)</th>
                    <th className="py-2.5 px-2 w-20 text-center">دانە</th>
                    <th className="py-2.5 px-2 w-28 text-left">کۆ</th>
                    <th className="py-2.5 px-2 w-10 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {items.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 space-y-1.5">
                        <select
                          onChange={(e) => {
                            if (e.target.value) {
                              handleItemSelectFromCatalog(item.id, e.target.value);
                            }
                          }}
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-purple-600"
                        >
                          <option value="">-- هەڵبژاردنی خێرا لە کۆگای شاشەکان --</option>
                          {products.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} ({p.sellPrice.toLocaleString()} دینار) [مەوجوود: {p.quantity}]
                            </option>
                          ))}
                        </select>
                        <input
                          type="text"
                          required
                          value={item.name}
                          onChange={(e) => handleUpdateItem(item.id, 'name', e.target.value)}
                          placeholder="ناوی شاشە یان ماددە بنووسە..."
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-bold focus:outline-purple-600"
                        />
                      </td>

                      <td className="py-2 px-2">
                        <input
                          type="number"
                          required
                          min={0}
                          value={item.price || ''}
                          onChange={(e) => handleUpdateItem(item.id, 'price', Number(e.target.value))}
                          placeholder="0"
                          className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold focus:outline-purple-600 text-left"
                        />
                      </td>

                      <td className="py-2 px-2 text-center">
                        <input
                          type="number"
                          min={1}
                          value={item.quantity || 1}
                          onChange={(e) => handleUpdateItem(item.id, 'quantity', Number(e.target.value))}
                          className="w-16 bg-white border border-slate-200 rounded-lg px-1.5 py-1.5 text-xs font-mono font-bold text-center focus:outline-purple-600 mx-auto"
                        />
                      </td>

                      <td className="py-2 px-2 text-left font-mono font-black text-slate-800">
                        {item.total.toLocaleString()}
                      </td>

                      <td className="py-2 px-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Payment & Calculations Box */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-600 font-bold mb-1">داشکاندن (دینار):</label>
                <input
                  type="number"
                  min={0}
                  value={discount || ''}
                  onChange={(e) => setDiscount(Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-purple-600 text-left"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-bold mb-1">پارەی دراو بە کاش (دینار):</label>
                <input
                  type="number"
                  min={0}
                  value={paidAmount || ''}
                  onChange={(e) => setPaidAmount(Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-white border border-emerald-300 rounded-xl px-3 py-2 text-xs font-mono font-black text-emerald-700 focus:outline-purple-600 text-left"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block">کۆی وەسڵ:</span>
                <span className="font-bold font-mono text-slate-900">{subTotal.toLocaleString()}</span>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block">پاش داشکاندن:</span>
                <span className="font-bold font-mono text-purple-700">{grandTotal.toLocaleString()}</span>
              </div>
              <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-400 block">قەرزی پێشوو:</span>
                <span className="font-bold font-mono text-slate-600">{previousDebt.toLocaleString()}</span>
              </div>
              <div className="bg-rose-50 p-2.5 rounded-xl border border-rose-200">
                <span className="text-[10px] text-rose-600 block font-bold">کۆی قەرزی ماوە:</span>
                <span className="font-black font-mono text-rose-700 text-sm">
                  {remainingDebt.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">تێبینی سەر وەسڵ:</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="تێبینی بۆ وەسڵ..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:outline-purple-600"
            />
          </div>

          {/* Submit Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition cursor-pointer"
            >
              پاشگەزبوونەوە
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
            >
              تەواوکردن و دەرکردنی وەسڵ
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
