import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { 
  Settings, 
  Store, 
  Phone, 
  MapPin, 
  User, 
  Lock, 
  DollarSign, 
  FileText, 
  Check, 
  Download, 
  Upload, 
  RotateCcw, 
  Save, 
  ShieldCheck,
  Mail,
  Copy,
  ExternalLink,
  Smartphone,
  Layers,
  Sparkles,
  AlertCircle,
  Code,
  CheckCircle2,
  ShieldAlert,
  KeyRound,
  Eye,
  EyeOff
} from 'lucide-react';
import { AdminRecoveryModal } from './AdminRecoveryModal';

export const SettingsManager: React.FC = () => {
  const { 
    settings, 
    updateSettings, 
    exportDatabase, 
    importDatabase, 
    resetDatabase,
    getDatabaseBackupJson,
    lockCurrentDataAsPermanentBase,
    isDataLocked,
    customers,
    invoices,
    products,
    stockLogs,
    dailySnapshots,
    createInstantSnapshot,
    restoreFromSnapshot,
    exportTableAsCsv
  } = useStore();

  const [shopName, setShopName] = useState(settings.shopName);
  const [subTitle, setSubTitle] = useState(settings.subTitle);
  const [ownerName, setOwnerName] = useState(settings.ownerName);
  const [phone1, setPhone1] = useState(settings.phone1);
  const [phone2, setPhone2] = useState(settings.phone2 || '');
  const [address, setAddress] = useState(settings.address);
  const [adminPin, setAdminPin] = useState(settings.adminPin);
  const [adminRecoveryKey, setAdminRecoveryKey] = useState(settings.adminRecoveryKey || 'HAWTA-996-SECURE');
  const [securityQuestion, setSecurityQuestion] = useState(settings.securityQuestion || 'ئیمەیڵی سەرەکی خاوەن فرۆشگا چییە؟');
  const [securityAnswer, setSecurityAnswer] = useState(settings.securityAnswer || 'wryaomer996@gmail.com');
  const [recoveryEmail, setRecoveryEmail] = useState(settings.recoveryEmail || 'wryaomer996@gmail.com');
  const [showAdminPin, setShowAdminPin] = useState(false);
  const [showMasterKey, setShowMasterKey] = useState(false);
  const [showRecoveryTestModal, setShowRecoveryTestModal] = useState(false);

  const [usdToIqdRate, setUsdToIqdRate] = useState(settings.usdToIqdRate);
  const [warrantyTerms, setWarrantyTerms] = useState(settings.warrantyTerms);
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(settings.lowStockThreshold ?? 2);
  const [thermalPaperWidth, setThermalPaperWidth] = useState<'80mm' | '58mm' | 'standard'>(
    settings.thermalPaperWidth || '80mm'
  );

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [snapshotTakenNotice, setSnapshotTakenNotice] = useState(false);

  // Email Backup & Restore States
  const [backupEmail, setBackupEmail] = useState('wryaomer996@gmail.com');
  const [restoreText, setRestoreText] = useState('');
  const [copiedBackup, setCopiedBackup] = useState(false);
  const [emailStatus, setEmailStatus] = useState<string | null>(null);
  const [lockSuccess, setLockSuccess] = useState(false);

  const handleLockData = () => {
    lockCurrentDataAsPermanentBase();
    setLockSuccess(true);
    setTimeout(() => setLockSuccess(false), 3500);
  };

  const handleTakeSnapshot = () => {
    createInstantSnapshot();
    setSnapshotTakenNotice(true);
    setTimeout(() => setSnapshotTakenNotice(false), 3000);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      shopName,
      subTitle,
      ownerName,
      phone1,
      phone2,
      address,
      adminPin,
      adminRecoveryKey,
      securityQuestion,
      securityAnswer,
      recoveryEmail,
      usdToIqdRate: Number(usdToIqdRate) || 152000,
      warrantyTerms,
      lowStockThreshold: Number(lowStockThreshold) || 2,
      thermalPaperWidth,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // Copy JSON backup
  const handleCopyBackup = () => {
    const jsonStr = getDatabaseBackupJson();
    navigator.clipboard.writeText(jsonStr);
    setCopiedBackup(true);
    setTimeout(() => setCopiedBackup(false), 2500);
  };

  // Send Backup via Email (Mailto & Direct Gmail)
  const handleSendEmailBackup = (useGmailWeb = false) => {
    const jsonStr = getDatabaseBackupJson();
    const dateStr = new Date().toISOString().substring(0, 10);
    const subject = `${settings.shopName || 'Mobile Store'} Database Backup - ${dateStr}`;
    
    // Email Body with summary statistics and backup JSON payload
    const bodyText = `سڵاو بەڕێز،\n\nئەمەش باکئەپی پارێزراوی داتابەیسی فرۆشگای ${settings.shopName || 'کۆگای مۆبایل'}ـە:\n` +
      `- بەروار: ${new Date().toLocaleString()}\n` +
      `- ژمارەی وەستاکان: ${customers.length}\n` +
      `- ژمارەی وەسڵەکان: ${invoices.length}\n` +
      `- ژمارەی کاڵا و شاشەکان: ${products.length}\n\n` +
      `-----------------------------------------\n` +
      `کۆدی تەواوی داتابەیس (بۆ گەڕاندنەوە لە سیستەم کۆپی بکە):\n\n` +
      jsonStr;

    if (useGmailWeb) {
      const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(backupEmail)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyText)}`;
      window.open(gmailUrl, '_blank');
    } else {
      const mailtoUrl = `mailto:${encodeURIComponent(backupEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyText)}`;
      window.location.href = mailtoUrl;
    }

    setEmailStatus('بەرنامەی ئیمەیڵ کرایەوە بۆ ناردنی باکئەپ.');
    setTimeout(() => setEmailStatus(null), 4000);
  };

  // Restore from pasted text
  const handleRestoreFromText = () => {
    if (!restoreText.trim()) {
      alert('تکایە سەرەتا کۆدی باکئەپ لێرە دابنێ');
      return;
    }

    if (confirm('ئایا دڵنیایت دەتەوێت داتابەیس لەم باکئەپە بگێڕیتەوە؟ هەموو زانیارییە کۆنەکان نوێ دەبنەوە.')) {
      const ok = importDatabase(restoreText.trim());
      if (ok) {
        alert('داتابەیس بە سەرکەوتوویی لە باکئەپەکە گەڕێندرایەوە!');
        window.location.reload();
      } else {
        alert('کۆدی باکئەپەکە هەڵەیە یان ناتەواوە. تکایە دڵنیابە لە دروستی دەقەکە.');
      }
    }
  };

  // Restore from file
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const content = ev.target?.result as string;
      if (content) {
        const ok = importDatabase(content);
        if (ok) {
          alert('داتابەیس بە سەرکەوتوویی گەڕێندرایەوە!');
          window.location.reload();
        } else {
          alert('کێشەیەک لە خوێندنەوەی فایلەکە ڕوویدا');
        }
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (confirm('ئایا دڵنیایت دەتەوێت هەموو داتاکان بگەڕێنیتەوە دۆخی سەرەتا؟')) {
      resetDatabase();
      alert('داتاکان گەڕێندرانەوە دۆخی سەرەتا.');
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-800 via-indigo-800 to-slate-900 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-purple-200">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black">ڕێکخستنەکانی سیستەم (Settings)</h1>
            <p className="text-xs text-purple-200 mt-0.5">
              گۆڕینی ناوی فرۆشگا، ژمارەی تەلەفۆن، ناونیشان، باکئەپی ئیمەیڵ، و ڕێکخستنی ئەپ
            </p>
          </div>
        </div>
      </div>

      {savedSuccess && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-2xl flex items-center gap-2 text-sm font-bold shadow-xs">
          <Check className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>زانیارییەکان بە سەرکەوتوویی پاشەکەوت کران و لە سەرجەم بەشەکان نوێکرانەوە.</span>
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSave} className="bg-white rounded-3xl p-5 sm:p-8 shadow-xl border border-slate-100 space-y-6">
        <h2 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3">
          <Store className="w-5 h-5 text-purple-600" />
          <span>زانیارییە سەرەکییەکانی فرۆشگا و پەیوەندی</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
          {/* Shop Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ناوی فرۆشگا / کۆمپانیا:
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-bold focus:outline-purple-600"
              />
            </div>
          </div>

          {/* Subtitle */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              ژێرنووس / ناساندنی کار:
            </label>
            <input
              type="text"
              value={subTitle}
              onChange={(e) => setSubTitle(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-medium focus:outline-purple-600"
            />
          </div>

          {/* Owner Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-purple-600" />
              <span>ناوی خاوەنی فرۆشگا:</span>
            </label>
            <input
              type="text"
              required
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-bold focus:outline-purple-600"
            />
          </div>

          {/* Primary Phone */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-purple-600" />
              <span>ژمارەی مۆبایل سەرەکی (وەتسئەپ):</span>
            </label>
            <input
              type="text"
              required
              dir="ltr"
              value={phone1}
              onChange={(e) => setPhone1(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold focus:outline-purple-600"
            />
          </div>

          {/* Secondary Phone */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span>ژمارەی دووەم (ئارەزوومەندانە):</span>
            </label>
            <input
              type="text"
              dir="ltr"
              value={phone2}
              onChange={(e) => setPhone2(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-mono font-medium focus:outline-purple-600"
            />
          </div>

          {/* Address */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-purple-600" />
              <span>شوێن و ناونیشان:</span>
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-sm font-medium focus:outline-purple-600"
            />
          </div>

          {/* Admin PIN - Secure, with toggle */}
          <div className="bg-purple-50/70 p-4 rounded-2xl border border-purple-100">
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-purple-900 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-purple-600" />
                <span>کۆدی نهێنی ئەدمین (Admin PIN):</span>
              </label>
              <button
                type="button"
                onClick={() => setShowAdminPin(!showAdminPin)}
                className="text-[11px] text-purple-700 hover:text-purple-900 font-bold flex items-center gap-1 cursor-pointer"
              >
                {showAdminPin ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showAdminPin ? 'شاردنەوە' : 'پیشاندان'}</span>
              </button>
            </div>
            <div className="relative">
              <input
                type={showAdminPin ? 'text' : 'password'}
                required
                dir="ltr"
                value={adminPin}
                onChange={(e) => setAdminPin(e.target.value)}
                placeholder="••••"
                className="w-full bg-white border border-purple-200 rounded-xl px-3.5 py-2.5 text-sm font-mono font-black focus:outline-purple-600"
              />
            </div>
            <p className="text-[11px] text-purple-700 mt-1.5 leading-relaxed">
              ئەم کۆدە تەنها لای بەڕێوەبەرە بۆ پاراستنی داشبۆرد و ڕێکخستنەکان لە کاتی بەکارهێنانی پۆرتاڵ لەلایەن وەستاکانەوە.
            </p>
          </div>

          {/* Dollar Exchange Rate */}
          <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-100">
            <label className="block text-xs font-bold text-emerald-900 mb-1 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              <span>نرخی ئاڵوگۆڕی 100 دۆلار بەرامبەر دینار:</span>
            </label>
            <input
              type="number"
              required
              dir="ltr"
              value={usdToIqdRate}
              onChange={(e) => setUsdToIqdRate(Number(e.target.value))}
              className="w-full bg-white border border-emerald-200 rounded-xl px-3.5 py-2.5 text-sm font-mono font-black text-emerald-800 focus:outline-emerald-600"
            />
            <p className="text-[11px] text-emerald-700 mt-1.5">
              کۆی کڕینی شاشەکان بە دۆلار و دینار بەپێی ئەم نرخە هەژمار دەکرێن.
            </p>
          </div>

          {/* Low Stock Alert Threshold */}
          <div className="bg-amber-50/70 p-4 rounded-2xl border border-amber-100">
            <label className="block text-xs font-bold text-amber-900 mb-1 flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span>ئاگاداری کەمی مەوجوودی لە کۆگا (Low Stock Alert):</span>
            </label>
            <input
              type="number"
              min={1}
              required
              dir="ltr"
              value={lowStockThreshold}
              onChange={(e) => setLowStockThreshold(Number(e.target.value))}
              className="w-full bg-white border border-amber-200 rounded-xl px-3.5 py-2.5 text-sm font-mono font-black text-amber-800 focus:outline-amber-600"
            />
            <p className="text-[11px] text-amber-700 mt-1.5">
              کاتێک ژمارەی شاشە یان پارچەیەک دەگاتە ئەم بڕە یان کەمتر، هۆشداری دەدات.
            </p>
          </div>

          {/* Thermal Receipt Paper Size */}
          <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-100">
            <label className="block text-xs font-bold text-blue-900 mb-1 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-blue-600" />
              <span>قەبارەی کاغەزی چاپکەری وەسڵ (Printer Format):</span>
            </label>
            <select
              value={thermalPaperWidth}
              onChange={(e: any) => setThermalPaperWidth(e.target.value)}
              className="w-full bg-white border border-blue-200 rounded-xl px-3.5 py-2.5 text-sm font-bold text-blue-900 focus:outline-blue-600 cursor-pointer"
            >
              <option value="80mm">🖨️ تێرمەڵ 80mm (کۆنتڕۆڵ و پۆس - باوترین)</option>
              <option value="58mm">🧾 تێرمەڵ 58mm (مینی پۆس و مۆبایل)</option>
              <option value="standard">📄 کاغەزی ئاسایی تەواو (A4 / Letter)</option>
            </select>
            <p className="text-[11px] text-blue-700 mt-1.5">
              شێوازی چاپکردنی وەسڵەکان بە شێوەی خودکار بەم قەبارەیە ڕێکدەخرێن.
            </p>
          </div>
        </div>

        {/* Invoice Terms & Warranty */}
        <div>
          <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
            <FileText className="w-3.5 h-3.5 text-purple-600" />
            <span>مەرجەکانی گەرەنتی شاشە (لە ژێر پسوولە چاپ دەبێت):</span>
          </label>
          <textarea
            rows={3}
            value={warrantyTerms}
            onChange={(e) => setWarrantyTerms(e.target.value)}
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs sm:text-sm font-medium focus:outline-purple-600 leading-relaxed"
          />
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-end pt-4 border-t border-slate-100">
          <button
            type="submit"
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-xl shadow-md hover:shadow-lg hover:from-purple-700 hover:to-indigo-700 transition flex items-center gap-2 text-sm cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>پاشەکەوتکردنی گۆڕانکارییەکان</span>
          </button>
        </div>
      </form>

      {/* ADMIN PIN RECOVERY & EMERGENCY MASTER KEY SECTION */}
      <div className="bg-white rounded-3xl p-5 sm:p-8 shadow-xl border border-amber-100/90 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            <span>پاراستن و ڕزگارکردنی کۆدی ئەدمین (Admin Recovery & Security Guard)</span>
          </h3>
          <span className="text-xs bg-amber-100 text-amber-800 font-bold px-2.5 py-0.5 rounded-lg flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            فریاگوزاری
          </span>
        </div>

        <div className="bg-gradient-to-r from-amber-50 to-purple-50 p-4 rounded-2xl border border-amber-200/70 text-xs text-slate-700 leading-relaxed space-y-1.5">
          <p className="font-bold text-slate-900 flex items-center gap-1.5 text-sm">
            <span>🛡️ کاتێک پاسۆردی ئەدمین لەدەستچوو یان کەسێک دەستکاری کرد؛ چۆن دەیگەڕێنیتەوە؟</span>
          </p>
          <p>
            تەنانەت ئەگەر کەسێک بە هەڵە یان بە مەبەست کۆدی ئەدمینەکەی لەناو فرۆشگا گۆڕیبێت، تۆ بە هۆی <strong>کۆدی فریاگوزاری (Master Key)</strong> یان <strong>پرسیاری ئەمنی تایبەتی خۆت</strong> دەتوانیت لە دەرەوە هەر کاتێک بێت بە یەک چرکە پینەکە بسڕیتەوە و کۆدێکی نوێ دابنێیت.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Master Emergency Recovery Key */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-purple-600" />
                <span>کۆدی فریاگوزاری سەرەکی (Master Emergency Key):</span>
              </label>
              <button
                type="button"
                onClick={() => setShowMasterKey(!showMasterKey)}
                className="text-[11px] text-purple-700 hover:text-purple-900 font-bold flex items-center gap-1 cursor-pointer"
              >
                {showMasterKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showMasterKey ? 'شاردنەوە' : 'پیشاندان'}</span>
              </button>
            </div>
            <div className="relative">
              <input
                type={showMasterKey ? 'text' : 'password'}
                dir="ltr"
                value={adminRecoveryKey}
                onChange={(e) => setAdminRecoveryKey(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-purple-900 focus:outline-purple-600"
              />
            </div>
            <p className="text-[11px] text-slate-500">
              ئەم کۆدە تەنها لای خۆت دەبێت و وەک ماستەر کلیل (Master Key) هەموو قفڵێک دەشکێنێت.
            </p>
          </div>

          {/* Recovery Email */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Mail className="w-4 h-4 text-indigo-600" />
              <span>ئیمەیڵی سەرەکی خاوەن فرۆشگا (Recovery Email):</span>
            </label>
            <input
              type="email"
              dir="ltr"
              value={recoveryEmail}
              onChange={(e) => setRecoveryEmail(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-slate-800 focus:outline-purple-600"
            />
            <p className="text-[11px] text-slate-500">
              داواکاری گەڕاندنەوە و کۆدی فریاگوزاری دەتوانرێت ڕەوانەی ئەم ئیمەیڵە بکرێت.
            </p>
          </div>

          {/* Security Question */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-amber-600" />
              <span>پرسیاری ئەمنی نهێنی (Secret Security Question):</span>
            </label>
            <input
              type="text"
              value={securityQuestion}
              onChange={(e) => setSecurityQuestion(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm font-bold text-slate-800 focus:outline-purple-600"
            />
            <p className="text-[11px] text-slate-500">
              پرسیارێک کە تەنها خۆت وەڵامەکەی دەزانیت بۆ کاتی لەدەستچوونی کۆد.
            </p>
          </div>

          {/* Security Answer */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>وەڵامی دروستی پرسیاری ئەمنی (Security Answer):</span>
            </label>
            <input
              type="text"
              value={securityAnswer}
              onChange={(e) => setSecurityAnswer(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm font-bold text-slate-800 focus:outline-purple-600"
            />
            <p className="text-[11px] text-slate-500">
              تەنها کەسێک کە ئەم وەڵامە بنووسێت دەتوانێت پین نوێ بکاتەوە.
            </p>
          </div>
        </div>

        {/* Quick Action & Test */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <button
            type="button"
            onClick={() => setShowRecoveryTestModal(true)}
            className="px-4 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-xs"
          >
            <KeyRound className="w-4 h-4 text-amber-700" />
            <span>تاقیکردنەوەی پەنجەرەی گەڕاندنەوەی کۆد (Test Recovery Flow)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              if (confirm('ئایا دڵنیایت دەتەوێت کۆدی ئەدمین بگەڕێنیتەوە بۆ کۆدی بنەڕەتی (7788)؟')) {
                setAdminPin('7788');
                updateSettings({ adminPin: '7788' });
                alert('کۆدی ئەدمین بە سەرکەوتوویی گەڕێندرایەوە بۆ: 7788');
              }
            }}
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>گەڕاندنەوەی خێرای پین بۆ بنەڕەتی (7788)</span>
          </button>
        </div>
      </div>

      {/* EMAIL BACKUP & RESTORE SECTION */}
      <div className="bg-white rounded-3xl p-5 sm:p-8 shadow-xl border border-slate-100 space-y-5">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
            <Mail className="w-5 h-5 text-purple-600" />
            <span>باکئەپ و گەڕاندنەوە لە ڕێگەی ئیمەیڵ (Email Backup & Restore)</span>
          </h3>
          <span className="text-xs bg-purple-100 text-purple-800 font-bold px-2.5 py-0.5 rounded-lg">
            پارێزراو
          </span>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          بۆ پاراستنی هەموو وەسڵەکان، شاشەکان و حیساباتی وەستاکان، دەتوانیت باکئەپ بنێریت بۆ ئیمەیڵەکەت و لە هەر کاتێک و لەسەر هەر مۆبایل و کۆمپیوتەرێک بگەڕێنیتەوە:
        </p>

        {/* Email Input & Dispatch */}
        <div className="bg-purple-50/60 p-4 sm:p-5 rounded-2xl border border-purple-200/80 space-y-3">
          <label className="block text-xs font-bold text-purple-900">
            ئیمەیڵی وەرگری باکئەپ (Email Address):
          </label>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="relative flex-1">
              <Mail className="w-4 h-4 text-purple-600 absolute right-3 top-3" />
              <input
                type="email"
                dir="ltr"
                value={backupEmail}
                onChange={(e) => setBackupEmail(e.target.value)}
                placeholder="wryaomer996@gmail.com"
                className="w-full bg-white border border-purple-200 rounded-xl pr-9 pl-3 py-2 text-xs sm:text-sm font-mono font-bold text-slate-800 focus:outline-purple-600"
              />
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleSendEmailBackup(true)}
                className="flex-1 sm:flex-none px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>ناردن بە Gmail</span>
              </button>

              <button
                type="button"
                onClick={() => handleSendEmailBackup(false)}
                className="flex-1 sm:flex-none px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer"
              >
                <Mail className="w-3.5 h-3.5" />
                <span>ناردن بە ئیمەیڵ</span>
              </button>
            </div>
          </div>

          {emailStatus && (
            <div className="text-xs text-emerald-700 font-bold bg-emerald-50 p-2 rounded-lg border border-emerald-200">
              ✓ {emailStatus}
            </div>
          )}

          {/* Lock & Persist Base Data */}
        <div className="bg-emerald-50/80 p-4 rounded-2xl border border-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700" />
              <span className="font-bold text-xs text-emerald-950">جێگیرکردنی تەواوی داتاکانی ئێستا (Lock Current Saved Data)</span>
              {isDataLocked && (
                <span className="text-[10px] bg-emerald-200 text-emerald-900 font-bold px-2 py-0.5 rounded-full">
                  جێگیرکراوە ✓
                </span>
              )}
            </div>
            <p className="text-[11px] text-emerald-800 leading-relaxed">
              تەواوی داتاکانی ئێستات (وەسڵەکان، کڕیاران، کۆگا و ڕێکخستنەکان) وەک بنکەی داتای سەرەکی و نەگۆڕ پاشەکەوت دەبن.
            </p>
          </div>

          <button
            type="button"
            onClick={handleLockData}
            className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition cursor-pointer shrink-0"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{lockSuccess ? '✓ داتاکان جێگیرکران' : 'جێگیرکردنی داتاکان'}</span>
          </button>
        </div>

        {/* Quick Copy JSON */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-purple-100">
            <button
              type="button"
              onClick={handleCopyBackup}
              className="px-3 py-2 bg-white hover:bg-purple-50 text-purple-700 border border-purple-200 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedBackup ? '✓ باکئەپ کۆپی کرا' : 'کۆپیکردنی دەقی باکئەپ'}</span>
            </button>

            <button
              type="button"
              onClick={exportDatabase}
              className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-2xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>داگرتنی فایلی باکئەپ (.json)</span>
            </button>
          </div>
        </div>

        {/* Restore from Text / Email */}
        <div className="space-y-3 pt-2">
          <label className="block text-xs font-bold text-slate-800">
            گەڕاندنەوەی باکئەپ لە دەقی ئیمەیڵ (Restore from Email Text):
          </label>
          <textarea
            rows={3}
            dir="ltr"
            value={restoreText}
            onChange={(e) => setRestoreText(e.target.value)}
            placeholder="دەقی باکئەپ لە ئیمەیڵەکەت کۆپی بکە و لێرە دایبنێ (Paste JSON Backup here)..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono focus:outline-purple-600"
          />

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleRestoreFromText}
              className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-sm transition cursor-pointer"
            >
              <Upload className="w-4 h-4" />
              <span>گەڕاندنەوەی داتابەیس (Restore Database)</span>
            </button>

            <label className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer">
              <FileText className="w-4 h-4" />
              <span>یان هەڵبژاردنی فایل (.json)</span>
              <input type="file" accept=".json" onChange={handleImportFile} className="hidden" />
            </label>

            <button
              type="button"
              onClick={handleReset}
              className="px-4 py-2.5 bg-rose-50 text-rose-600 hover:bg-rose-100 border border-rose-200 rounded-xl font-bold text-xs flex items-center gap-2 transition cursor-pointer mr-auto"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>گەڕاندنەوە بۆ سەرەتا</span>
            </button>
          </div>
        </div>
      </div>

      {/* CSV EXCEL DATA EXPORT SECTION */}
      <div className="bg-white rounded-3xl p-5 sm:p-8 shadow-xl border border-slate-100 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-600" />
            <span>دەرهێنانی داتاکان بە فایلی Excel / CSV (Export Tables)</span>
          </h3>
          <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-lg">
            Excel Ready
          </span>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          دەتوانیت هەر بەشێکی داتابەیس بە جیا بۆ خشتەی Excel یان Google Sheets داگریت بۆ ژمێریاری و وردبینی:
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            type="button"
            onClick={() => exportTableAsCsv('customers')}
            className="p-3.5 bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-2xl font-bold text-xs flex flex-col items-center justify-center gap-2 transition cursor-pointer group"
          >
            <User className="w-5 h-5 text-purple-600 group-hover:scale-110 transition-transform" />
            <span>خشتەی وەستاکان (Excel)</span>
            <span className="text-[10px] text-slate-400 font-normal">{customers.length} تۆمار</span>
          </button>

          <button
            type="button"
            onClick={() => exportTableAsCsv('invoices')}
            className="p-3.5 bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-2xl font-bold text-xs flex flex-col items-center justify-center gap-2 transition cursor-pointer group"
          >
            <FileText className="w-5 h-5 text-blue-600 group-hover:scale-110 transition-transform" />
            <span>خشتەی وەسڵەکان (Excel)</span>
            <span className="text-[10px] text-slate-400 font-normal">{invoices.length} وەسڵ</span>
          </button>

          <button
            type="button"
            onClick={() => exportTableAsCsv('products')}
            className="p-3.5 bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-2xl font-bold text-xs flex flex-col items-center justify-center gap-2 transition cursor-pointer group"
          >
            <Smartphone className="w-5 h-5 text-indigo-600 group-hover:scale-110 transition-transform" />
            <span>شاشە و کۆگا (Excel)</span>
            <span className="text-[10px] text-slate-400 font-normal">{products.length} ماددە</span>
          </button>

          <button
            type="button"
            onClick={() => exportTableAsCsv('stockLogs')}
            className="p-3.5 bg-slate-50 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-2xl font-bold text-xs flex flex-col items-center justify-center gap-2 transition cursor-pointer group"
          >
            <Layers className="w-5 h-5 text-amber-600 group-hover:scale-110 transition-transform" />
            <span>جووڵەی مەخزەن (Excel)</span>
            <span className="text-[10px] text-slate-400 font-normal">{stockLogs.length} جووڵە</span>
          </button>
        </div>
      </div>

      {/* DAILY SNAPSHOTS & RECOVERY SECTION */}
      <div className="bg-white rounded-3xl p-5 sm:p-8 shadow-xl border border-slate-100 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
            <Layers className="w-5 h-5 text-purple-600" />
            <span>باکئەپ و مێژووی ڕۆژانەی داتابەیس (Daily Snapshots)</span>
          </h3>
          <button
            type="button"
            onClick={handleTakeSnapshot}
            className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{snapshotTakenNotice ? '✓ کۆپی کرا' : 'کۆپیکردنی خێرای ئێستا'}</span>
          </button>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          سیستەم لە هەموو ڕۆژێکدا بە شێوەیەکی خودکار کۆپییەکی پارێزراو لە تەواوی حساباتەکە هەڵدەگرێت تاوەکو لە ئەگەری هەر هەڵەیەک بتوانیت بە یەک کلیک بگەڕێیتەوە بۆ مێژووی ڕۆژانی پێشوو:
        </p>

        {dailySnapshots.length === 0 ? (
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center text-xs text-slate-500">
            هێشتا هیچ کۆپییەکی ڕۆژانە تۆمار نەکراوە. کلیک لە دوگمەی «کۆپیکردنی خێرای ئێستا» بکە.
          </div>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {dailySnapshots.map((snap) => (
              <div
                key={snap.id}
                className="p-3.5 bg-slate-50 hover:bg-purple-50/40 rounded-2xl border border-slate-200 flex items-center justify-between gap-3 transition"
              >
                <div>
                  <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
                    <span className="font-mono text-purple-700">{snap.date}</span>
                    <span className="text-[10px] text-slate-400 font-normal">
                      {new Date(snap.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 flex items-center gap-3 mt-1 font-mono">
                    <span>{snap.customersCount} کڕیار</span>
                    <span>•</span>
                    <span>{snap.invoicesCount} وەسڵ</span>
                    <span>•</span>
                    <span>{snap.productsCount} شاشە</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (confirm(`ئایا دڵنیایت دەتەوێت داتابەیس بۆ ڕۆژی ${snap.date} بگەڕێنیتەوە؟`)) {
                      restoreFromSnapshot(snap.id);
                    }
                  }}
                  className="px-3 py-1.5 bg-white hover:bg-purple-600 text-purple-700 hover:text-white border border-purple-200 hover:border-purple-600 rounded-xl text-xs font-bold transition cursor-pointer shadow-2xs"
                >
                  گەڕاندنەوە
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* CODEMAGIC.IO & APP CONFIGURATION GUIDE */}
      <div className="bg-white rounded-3xl p-5 sm:p-8 shadow-xl border border-slate-100 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-indigo-600" />
            <span>دروستکردنی ئەپ بۆ Android و iOS لە ڕێگەی Codemagic.io</span>
          </h3>
          <span className="text-xs bg-indigo-100 text-indigo-800 font-bold px-2.5 py-0.5 rounded-lg font-mono">
            Codemagic Ready
          </span>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          سیستەمەکە بە تەواوی ئامادەکراوە بۆ ئەوەی ڕاستەوخۆ لە ماڵپەڕی <strong className="text-indigo-700">Codemagic.io</strong> بیکەیت بە ئەپ بۆ هەردوو سیستەمی ئەندرۆید (APK/AAB) و ئایفۆن (IPA):
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900 block flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs">١</span>
              <span>کۆدی capacitor.config.json</span>
            </span>
            <p className="text-[11px] text-slate-500">
              ناسنامەی ئەپ: <code className="font-mono text-purple-700 font-bold">com.wryamobile.store</code>
            </p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900 block flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs">٢</span>
              <span>فایلی codemagic.yaml</span>
            </span>
            <p className="text-[11px] text-slate-500">
              ڕێکخستنی خودکاری بەرهەمهێنانی APK و IPA بە مۆڵەتی تەواوی Gradle و CocoaPods.
            </p>
          </div>

          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-1">
            <span className="font-bold text-slate-900 block flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs">٣</span>
              <span>PWA & App Icons</span>
            </span>
            <p className="text-[11px] text-slate-500">
              ئایکۆنی 512x512 و 192x192 و دۆخی Standalone بەبێ ناونیشانی وێب.
            </p>
          </div>
        </div>

        {/* Step by step for user */}
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2.5 text-xs">
          <div className="font-bold text-slate-800">هەنگاوە ئاسانەکان بۆ بەدەستهێنانی ئەپی مۆبایل (Codemagic):</div>
          
          {/* Note about GitHub login issues */}
          <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-900 leading-relaxed">
            <span className="font-bold">⚠️ ئەگەر Export to GitHub داخڵ نەبوو:</span>
            <ul className="list-disc list-inside mt-1 space-y-1 text-[11px] text-amber-800">
              <li>لە براوزەردا <strong>Pop-up Blocker</strong> دەبێت ناچالاک بکەیت تاوەکو پەنجەرەی پەسەندکردنی GitHub بکرێتەوە.</li>
              <li>باشترە لەسەر <strong>کۆمپیوتەر یان لاپتۆپ</strong> و لە ڕێگەی براوزەری Chrome بیکەیت.</li>
              <li><strong>یان زۆر ئاسانتر:</strong> لە مینیۆی سەرەوەی ئەپەکە کلیک لە <strong>«Download ZIP»</strong> بکە، فایلەکان بە یەک کلیک دادەبەزن و ڕاستەوخۆ دەتوانیت لە GitHub داینێیت بەبێ گیران!</li>
            </ul>
          </div>

          <ol className="list-decimal list-inside space-y-2 text-slate-600 leading-relaxed pr-1">
            <li>لە مینیۆی سەرەوەی پڕۆژەکە (لە بەشی Settings یان تەنیشت دوگمەی Share) کلیک لە <strong>Export to GitHub</strong> یان <strong>Download ZIP</strong> بکە.</li>
            <li>بچۆ ناو ماڵپەڕی فەرمی <a href="https://codemagic.io" target="_blank" rel="noreferrer" className="text-indigo-600 font-bold underline">codemagic.io</a> و بە هەژماری خۆت داخڵ بە.</li>
            <li>دوگمەی <strong>«Add application»</strong> لێبدە و ڕیپۆستۆریی پڕۆژەکەت دیاریبکە.</li>
            <li>سیستەمی Codemagic ڕاستەوخۆ فایلی <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 text-purple-700 font-bold">codemagic.yaml</code> دەدۆزێتەوە.</li>
            <li>دوگمەی <strong>«Start new build»</strong> دابگرە:
              <ul className="list-disc list-inside mt-1 mr-4 space-y-1 text-slate-700">
                <li>بۆ ئەندرۆید: <strong>android-workflow</strong> هەڵبژێرە (فایلی <strong>.apk</strong> یان <strong>.aab</strong> ئامادە دەکات).</li>
                <li>بۆ ئایفۆن: <strong>ios-workflow</strong> هەڵبژێرە (فایلی <strong>.ipa</strong> یان <strong>.app</strong> ئامادە دەکات).</li>
              </ul>
            </li>
            <li>پاش تەواوبوون، فایلی ئەپەکە لە ماڵپەڕی Codemagic بە دوگمەی <strong>Download APK</strong> دادەبەزێت و لینکی ڕاستەوخۆ دەگاتە دەستت!</li>
          </ol>
        </div>
      </div>

      {/* Admin Recovery Test Modal */}
      <AdminRecoveryModal
        isOpen={showRecoveryTestModal}
        onClose={() => setShowRecoveryTestModal(false)}
        onSuccess={() => {
          setShowRecoveryTestModal(false);
          // Sync local state with updated settings
          setAdminPin(settings.adminPin);
        }}
      />
    </div>
  );
};
