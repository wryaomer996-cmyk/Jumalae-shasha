import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Invoice } from '../types';
import { InvoiceReceiptModal } from './InvoiceReceiptModal';
import { QuickScreenSearch } from './QuickScreenSearch';
import { 
  TrendingUp, 
  CreditCard, 
  Package, 
  Receipt, 
  UserPlus, 
  Plus, 
  Eye, 
  ArrowUpRight, 
  Download, 
  Upload, 
  RotateCcw, 
  DollarSign, 
  Calendar,
  Smartphone,
  ExternalLink,
  Layers,
  Settings,
  ShieldCheck,
  CheckCircle,
  Search,
  Lock
} from 'lucide-react';

interface AdminDashboardProps {
  onOpenNewInvoice: () => void;
  onOpenCustomers: () => void;
  onOpenInventory: () => void;
  onOpenSettings: () => void;
  onOpenCustomerPortal?: (customerId: number) => void;
  onLockToFrontPage?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onOpenNewInvoice,
  onOpenCustomers,
  onOpenInventory,
  onOpenSettings,
  onOpenCustomerPortal,
  onLockToFrontPage,
}) => {
  const {
    customers,
    invoices,
    products,
    transactions,
    settings,
    exportDatabase,
    getCustomerStats,
  } = useStore();

  const [selectedInvoiceForView, setSelectedInvoiceForView] = useState<Invoice | null>(null);
  const [calculatorUsd, setCalculatorUsd] = useState<number>(100);

  // Calculate high-level KPIs
  const totalDebtsOwed = customers.reduce((sum, c) => sum + getCustomerStats(c.id).totalDebt, 0);
  const totalScreensCount = products.filter((p) => p.category === 'screen').reduce((sum, p) => sum + p.quantity, 0);
  const totalInvoicesRevenue = invoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
  const totalStockCount = products.reduce((sum, p) => sum + p.quantity, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner with Quick Actions */}
      <div className="bg-gradient-to-r from-purple-800 via-indigo-800 to-slate-900 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full bg-purple-500/30 text-purple-200 text-xs font-bold border border-purple-400/20">
                {settings.shopName}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black">داشبۆردی بەڕێوەبردن و کۆگای شاشە</h1>
            <p className="text-xs sm:text-sm text-purple-200 mt-1 max-w-xl">
              کۆنترۆڵی جوملەی شاشەکان، پسوولەی وەستاکان، قەرزەکان و ڕێکخستنی سیستەم
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onOpenNewInvoice}
              className="px-4 py-2.5 bg-white text-purple-800 hover:bg-purple-50 font-black rounded-xl text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
            >
              <Plus className="w-4 h-4 text-purple-600" />
              <span>دەرکردنی وەسڵی نوێ</span>
            </button>

            {onLockToFrontPage && (
              <button
                onClick={onLockToFrontPage}
                title="قفڵکردن و گەڕانەوە بۆ پەڕەی سەرەکی و پۆرتاڵی وەستاکان"
                className="px-4 py-2.5 bg-slate-900/60 hover:bg-slate-900 text-purple-200 hover:text-white font-bold rounded-xl text-xs flex items-center gap-1.5 border border-purple-400/20 transition cursor-pointer shadow-sm"
              >
                <Lock className="w-4 h-4 text-purple-400" />
                <span>پەڕەی پێشەوە (وەستاکان)</span>
              </button>
            )}

            <button
              onClick={onOpenSettings}
              className="px-4 py-2.5 bg-purple-700/60 hover:bg-purple-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 border border-purple-400/30 transition cursor-pointer"
            >
              <Settings className="w-4 h-4" />
              <span>ڕێکخستنەکان</span>
            </button>

            <button
              onClick={() => {
                const el = document.getElementById('quick-screen-search-section');
                if (el) {
                  el.scrollIntoView({ behavior: 'smooth' });
                  const input = document.getElementById('quick-screen-search-input');
                  if (input) input.focus();
                }
              }}
              className="px-4 py-2.5 bg-indigo-600/70 hover:bg-indigo-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 border border-indigo-400/30 transition cursor-pointer shadow-sm"
            >
              <Search className="w-4 h-4 text-indigo-200" />
              <span>گەڕانی شاشە و نرخ</span>
            </button>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Debts Card */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 hover:shadow-md transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500">کۆی قەرزی لای وەستاکان</span>
            <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-rose-600 font-mono">
            {totalDebtsOwed.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">دیناری عێراقی ماوە لای وەستاکان</p>
        </div>

        {/* Total Wholesale Screens in Stock */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 hover:shadow-md transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500">شاشەی مەوجوود لە کۆگا</span>
            <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
              <Smartphone className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            {totalScreensCount} دانە
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            کۆی گشتی کەلوپەل: {totalStockCount} دانە
          </p>
        </div>

        {/* Total Cash Collected */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 hover:shadow-md transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500">کۆی پارەی وەرگیراو</span>
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono">
            {totalInvoicesRevenue.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">پارەی وەسڵە دراوەکان (کاش)</p>
        </div>

        {/* Total Technicians & Customers */}
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 hover:shadow-md transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500">کڕیاران و وەستاکان</span>
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <UserPlus className="w-5 h-5" />
            </div>
          </div>
          <div className="text-2xl font-black text-indigo-700 font-mono">
            {customers.length} کەس
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            وەستای تۆمارکراو بە کۆدی نهێنی
          </p>
        </div>
      </div>

      {/* Quick Screen Search & Live Price Checker */}
      <QuickScreenSearch onOpenNewInvoice={onOpenNewInvoice} />

      {/* Main Sections: Recent Invoices & Quick Wholesale Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Invoices List */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Receipt className="w-5 h-5 text-purple-600" />
              <h2 className="text-lg font-black text-slate-800">دوایین وەسڵە تۆمارکراوەکان</h2>
            </div>
            <button
              onClick={onOpenNewInvoice}
              className="text-xs text-purple-700 hover:text-purple-900 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>وەسڵی نوێ</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 bg-slate-50/50">
                  <th className="py-2.5 px-3">وەسڵ</th>
                  <th className="py-2.5 px-3">وەستا / کڕیار</th>
                  <th className="py-2.5 px-3">بەروار</th>
                  <th className="py-2.5 px-3 text-left">کۆ</th>
                  <th className="py-2.5 px-3 text-left">قەرز</th>
                  <th className="py-2.5 px-3 text-center">کردار</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.slice(0, 6).map((inv) => {
                  const cust = customers.find((c) => c.id === inv.customerId);
                  return (
                    <tr key={inv.id} className="hover:bg-purple-50/40 transition">
                      <td className="py-3 px-3 font-mono font-bold text-purple-700">
                        #{inv.id}
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-800">
                        {cust ? cust.name : `کڕیار #${inv.customerId}`}
                      </td>
                      <td className="py-3 px-3 text-slate-500 text-xs font-mono" dir="ltr">
                        {inv.date.substring(0, 10)}
                      </td>
                      <td className="py-3 px-3 text-left font-mono font-bold text-slate-900">
                        {inv.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-left font-mono font-extrabold text-rose-600">
                        {inv.remainingDebt.toLocaleString()}
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => setSelectedInvoiceForView(inv)}
                          className="p-1.5 text-purple-600 hover:bg-purple-100 rounded-lg transition cursor-pointer"
                          title="بینینی پسوولە"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 1 Col: Quick Exchange Rate & Screens Overview */}
        <div className="space-y-6">
          {/* Currency Calculator */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-600" />
              <span>گۆڕینەوەی دۆلار و دینار</span>
            </h3>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/70 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">نرخی دیاریکراوی 100$:</span>
                <span className="font-mono font-black text-purple-700 text-sm">
                  {(settings.usdToIqdRate || 152000).toLocaleString()} دینار
                </span>
              </div>

              <div>
                <label className="text-xs text-slate-500 block mb-1">بڕی دۆلار ($):</label>
                <input
                  type="number"
                  value={calculatorUsd}
                  onChange={(e) => setCalculatorUsd(Number(e.target.value))}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-sm font-mono font-bold text-slate-800 focus:outline-purple-600"
                />
              </div>

              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-sm">
                <span className="text-slate-600 font-bold">بەرامبەر بە دینار:</span>
                <span className="font-black font-mono text-emerald-700 text-base">
                  {((calculatorUsd * (settings.usdToIqdRate || 152000)) / 100).toLocaleString()} دینار
                </span>
              </div>
            </div>
          </div>

          {/* Quick Wholesale Screens Shortcuts */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-purple-600" />
                <span>شاشە پڕفرۆشەکان</span>
              </h3>
              <button
                onClick={onOpenInventory}
                className="text-xs text-purple-600 hover:text-purple-800 font-bold cursor-pointer"
              >
                بینینی هەمووی ←
              </button>
            </div>

            <div className="space-y-2.5">
              {products
                .filter((p) => p.category === 'screen')
                .slice(0, 4)
                .map((scr) => (
                  <div
                    key={scr.id}
                    className="p-2.5 bg-slate-50 hover:bg-purple-50/50 rounded-xl border border-slate-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-slate-900">{scr.name}</div>
                      <span className="text-[10px] text-slate-400">کواڵیتی: {scr.screenQuality || 'ئەسڵی'}</span>
                    </div>
                    <div className="text-left">
                      <span className="font-mono font-black text-purple-700 block">
                        {scr.sellPrice.toLocaleString()} د.ع
                      </span>
                      <span className="text-[10px] text-emerald-700 font-bold">
                        مەوجوود: {scr.quantity}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>

      {/* Invoice Viewer Modal */}
      {selectedInvoiceForView && (
        <InvoiceReceiptModal
          invoice={selectedInvoiceForView}
          onClose={() => setSelectedInvoiceForView(null)}
        />
      )}
    </div>
  );
};
