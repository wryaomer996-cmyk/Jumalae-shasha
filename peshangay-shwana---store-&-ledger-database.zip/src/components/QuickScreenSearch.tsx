import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductItem } from '../types';
import { 
  Search, 
  Smartphone, 
  Check, 
  Copy, 
  Plus, 
  DollarSign, 
  Tag, 
  Sparkles, 
  Layers, 
  MessageSquare, 
  X,
  ArrowUpDown,
  Share2,
  CheckCircle2
} from 'lucide-react';

interface QuickScreenSearchProps {
  onOpenNewInvoice?: (preselectedProduct?: ProductItem) => void;
  fullPage?: boolean;
  readOnly?: boolean;
}

export const QuickScreenSearch: React.FC<QuickScreenSearchProps> = ({ 
  onOpenNewInvoice,
  fullPage = false,
  readOnly = false 
}) => {
  const { products, settings, currency } = useStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [selectedQuality, setSelectedQuality] = useState<string>('all');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'name' | 'price_asc' | 'price_desc' | 'stock'>('name');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Only screens (or products where category is 'screen' or name includes screen keywords)
  const screens = useMemo(() => {
    return products.filter((p) => p.category === 'screen' || p.name.includes('شاشە'));
  }, [products]);

  // Extract unique brands for screen items
  const brandList = useMemo(() => {
    const brands = new Set<string>();
    screens.forEach((s) => {
      if (s.brand) brands.add(s.brand.trim());
    });
    return Array.from(brands);
  }, [screens]);

  // Filtered screens
  const filteredScreens = useMemo(() => {
    return screens
      .filter((s) => {
        // Search term matching
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase().trim();
          const matchName = s.name.toLowerCase().includes(q);
          const matchBrand = (s.brand || '').toLowerCase().includes(q);
          const matchModel = (s.screenModel || '').toLowerCase().includes(q);
          const matchQuality = (s.screenQuality || '').toLowerCase().includes(q);
          const matchNotes = (s.notes || '').toLowerCase().includes(q);
          if (!matchName && !matchBrand && !matchModel && !matchQuality && !matchNotes) {
            return false;
          }
        }

        // Brand filter
        if (selectedBrand !== 'all') {
          if (s.brand?.toLowerCase() !== selectedBrand.toLowerCase()) {
            return false;
          }
        }

        // Quality filter
        if (selectedQuality !== 'all') {
          if (s.screenQuality !== selectedQuality) {
            return false;
          }
        }

        // Stock filter
        if (inStockOnly && s.quantity <= 0) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price_asc') return a.sellPrice - b.sellPrice;
        if (sortBy === 'price_desc') return b.sellPrice - a.sellPrice;
        if (sortBy === 'stock') return b.quantity - a.quantity;
        return a.name.localeCompare(b.name, 'ku');
      });
  }, [screens, searchTerm, selectedBrand, selectedQuality, inStockOnly, sortBy]);

  // Helper to get USD equivalent
  const getUsdPrice = (iqd: number) => {
    const rate = settings.usdToIqdRate || 152000;
    const usd = (iqd / rate) * 100;
    return usd.toFixed(1);
  };

  // Copy screen details
  const handleCopy = (screen: ProductItem) => {
    const usd = getUsdPrice(screen.sellPrice);
    const text = `📱 ${screen.name}\nکواڵیتی: ${screen.screenQuality || 'ئەسڵی'}\nنرخی جوملە: ${screen.sellPrice.toLocaleString()} دینار ($${usd})\nمەوجوود: ${screen.quantity} دانە\nفرۆشگای ${settings.shopName}`;
    navigator.clipboard.writeText(text);
    setCopiedId(screen.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  // WhatsApp share
  const handleWhatsAppShare = (screen: ProductItem) => {
    const usd = getUsdPrice(screen.sellPrice);
    const text = `سڵاو بەڕێزم،\nزانیاری لەسەر:\n📱 ${screen.name}\nکواڵیتی: ${screen.screenQuality || 'ئەسڵی'}\nنرخی جوملە: ${screen.sellPrice.toLocaleString()} دینار ($${usd})\nمەوجوود لە کۆگا: ${screen.quantity} دانە`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const getQualityBadgeClass = (quality?: string) => {
    switch (quality) {
      case 'Original Service Pack':
        return 'bg-emerald-100 text-emerald-800 border-emerald-300';
      case 'OLED':
        return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'Incell':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-amber-100 text-amber-800 border-amber-300';
    }
  };

  return (
    <section 
      id="quick-screen-search-section"
      className={`bg-white rounded-3xl p-5 sm:p-6 shadow-sm border border-slate-200/90 space-y-5 transition-all ${
        fullPage ? 'max-w-7xl mx-auto' : ''
      }`}
    >
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-500/20 shrink-0">
            <Search className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                گەڕانی خێرای شاشە و نرخەکان
              </h2>
              <span className="px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 text-xs font-bold border border-purple-200">
                {screens.length} مۆدێل لە کۆگادا
              </span>
              {(readOnly || !onOpenNewInvoice) && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[11px] font-black border border-emerald-200">
                  خوێندنەوە (Read-Only)
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              ڕاستەوخۆ بەپێی مۆدێل، مارکە، کواڵیتی و نرخ بگەڕێ و زانیارییەکان بنێرە
            </p>
          </div>
        </div>

        {/* Live USD Rate Indicator */}
        <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-mono">
          <span className="text-slate-500 font-medium">100$ =</span>
          <span className="font-black text-purple-700">
            {(settings.usdToIqdRate || 152000).toLocaleString()} د.ع
          </span>
        </div>
      </div>

      {/* Main Search Input & Quick Controls */}
      <div className="space-y-3">
        <div className="relative">
          <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-5 h-5 text-purple-600" />
          </div>
          <input
            id="quick-screen-search-input"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ناوی شاشە بنووسە... (بۆ نموونە: iPhone 13 Pro, A52, OLED, Redmi Note, Incell...)"
            className="w-full pr-11 pl-10 py-3 bg-slate-50/80 hover:bg-white focus:bg-white border-2 border-slate-200 focus:border-purple-600 rounded-2xl text-sm font-bold text-slate-900 placeholder:text-slate-400 transition shadow-inner focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1">
          {/* Brand Filter */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-[11px] font-bold text-slate-500 ml-1">مارکە:</span>
            <button
              onClick={() => setSelectedBrand('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
                selectedBrand === 'all'
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              هەمووی ({screens.length})
            </button>
            {brandList.map((brand) => (
              <button
                key={brand}
                onClick={() => setSelectedBrand(brand)}
                className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
                  selectedBrand === brand
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {brand}
              </button>
            ))}
          </div>

          {/* Additional Filter Switches & Sort */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Quality Select */}
            <select
              value={selectedQuality}
              onChange={(e) => setSelectedQuality(e.target.value)}
              aria-label="فلتەری کواڵیتی شاشە"
              className="bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5 font-bold text-slate-700 cursor-pointer focus:outline-purple-600"
            >
              <option value="all">هەموو کواڵیتییەکان</option>
              <option value="Original Service Pack">ئەسڵی (Original)</option>
              <option value="OLED">ئۆلید (OLED GX)</option>
              <option value="Incell">ئینسێل (Incell)</option>
            </select>

            {/* In Stock Only Checkbox */}
            <label className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200/80 px-2.5 py-1.5 rounded-xl cursor-pointer select-none text-slate-700 font-bold transition">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="w-3.5 h-3.5 accent-purple-600 rounded"
              />
              <span>تەنها بەردەست</span>
            </label>

            {/* Sort Select */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              aria-label="ڕیزکردنی شاشەکان"
              className="bg-slate-100 border border-slate-200 rounded-xl px-2.5 py-1.5 font-bold text-slate-700 cursor-pointer focus:outline-purple-600"
            >
              <option value="name">ڕیزکردن: بەپێی ناو</option>
              <option value="price_asc">نرخ: لە هەرزانەوە</option>
              <option value="price_desc">نرخ: لە گرانەوە</option>
              <option value="stock">مەوجوود: زۆرترین</option>
            </select>
          </div>
        </div>
      </div>

      {/* Screen Cards Grid */}
      <div className="pt-2">
        <div className="flex items-center justify-between text-xs text-slate-500 mb-3 px-1">
          <span>دۆزراوەکان: <strong className="text-purple-700 font-black">{filteredScreens.length}</strong> شاشە</span>
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="text-purple-600 hover:text-purple-800 font-bold"
            >
              سڕینەوەی وشەی گەڕان
            </button>
          )}
        </div>

        {filteredScreens.length === 0 ? (
          <div className="p-10 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <Smartphone className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-slate-600">هیچ شاشەیەک بەم مەرجانە نەدۆزرایەوە</p>
            <p className="text-xs text-slate-400 mt-1">تکایە ناوی مۆدێلەکە کورتتر بنووسە یان فلتەرەکان لابدە</p>
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedBrand('all');
                setSelectedQuality('all');
                setInStockOnly(false);
              }}
              className="mt-4 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
            >
              پاککردنەوەی فلتەرەکان
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredScreens.map((screen) => {
              const usdVal = getUsdPrice(screen.sellPrice);
              const isCopied = copiedId === screen.id;

              return (
                <div
                  key={screen.id}
                  className="bg-slate-50/60 hover:bg-purple-50/40 rounded-2xl p-4 border border-slate-200/90 hover:border-purple-300 transition-all flex flex-col justify-between gap-3 shadow-2xs hover:shadow-xs group"
                >
                  {/* Top info */}
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <h3 className="text-sm font-black text-slate-900 group-hover:text-purple-900 transition leading-snug">
                        {screen.name}
                      </h3>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-md border shrink-0 ${getQualityBadgeClass(screen.screenQuality)}`}>
                        {screen.screenQuality || 'ئەسڵی'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      <span className="font-bold text-slate-600">{screen.brand}</span>
                      {screen.screenModel && (
                        <>
                          <span>•</span>
                          <span className="font-mono">{screen.screenModel}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Pricing and Stock */}
                  <div className="bg-white p-3 rounded-xl border border-slate-200/80 flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400 font-bold">نرخی جوملە</div>
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-base font-black font-mono text-purple-800">
                          {screen.sellPrice.toLocaleString()}
                        </span>
                        <span className="text-[11px] font-bold text-purple-600">دینار</span>
                        <span className="text-xs font-mono font-bold text-slate-400">
                          (${usdVal})
                        </span>
                      </div>
                    </div>

                    <div className="text-left">
                      <div className="text-[10px] text-slate-400 font-bold">مەوجوودی کۆگا</div>
                      {screen.quantity > 2 ? (
                        <span className="inline-flex items-center gap-1 text-xs font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>{screen.quantity} دانە</span>
                        </span>
                      ) : screen.quantity > 0 ? (
                        <span className="inline-flex items-center gap-1 text-xs font-black text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                          <span>تەنها {screen.quantity} دانە</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-xs font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                          تەواوبووە
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="flex items-center gap-1.5 pt-1">
                    {/* Copy button */}
                    <button
                      type="button"
                      onClick={() => handleCopy(screen)}
                      title="کۆپیکردنی نرخ و زانیاری شاشە"
                      className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer ${
                        isCopied
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>کۆپیکرا ✓</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-400" />
                          <span>کۆپیکردن</span>
                        </>
                      )}
                    </button>

                    {/* WhatsApp share */}
                    <button
                      type="button"
                      onClick={() => handleWhatsAppShare(screen)}
                      title="ناردن بە واتساپ"
                      className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl transition cursor-pointer"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </button>

                    {/* Create Invoice button */}
                    {onOpenNewInvoice && (
                      <button
                        type="button"
                        onClick={() => onOpenNewInvoice(screen)}
                        title="دەرکردنی وەسڵ بەم شاشەیە"
                        className="py-1.5 px-3 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition cursor-pointer shadow-2xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>وەسڵ</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
