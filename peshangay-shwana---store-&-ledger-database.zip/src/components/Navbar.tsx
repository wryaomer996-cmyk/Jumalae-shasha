import React from 'react';
import { useStore } from '../context/StoreContext';
import { 
  Smartphone, 
  LayoutDashboard, 
  UserCheck, 
  Users, 
  Layers, 
  Settings, 
  Plus, 
  Search,
  Lock
} from 'lucide-react';

export type ActiveTab = 'dashboard' | 'screen_search' | 'inventory' | 'customers' | 'settings' | 'customer_portal';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenNewInvoice: () => void;
  selectedCustomerId?: number;
  setSelectedCustomerId: (id?: number) => void;
  onLockToFrontPage?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewInvoice,
  selectedCustomerId,
  setSelectedCustomerId,
  onLockToFrontPage,
}) => {
  const { customers, settings, currency, setCurrency } = useStore();

  return (
    <header className="no-print sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & Brand */}
          <div
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer select-none"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-purple-500/20">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <div className="font-black text-slate-900 text-sm sm:text-base leading-tight">
                {settings.shopName}
              </div>
              <div className="text-[10px] font-bold text-purple-600 truncate max-w-[180px] sm:max-w-xs">
                {settings.subTitle}
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100/90 p-1 rounded-2xl text-xs font-bold">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition cursor-pointer ${
                activeTab === 'dashboard'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>داشبۆرد</span>
            </button>

            <button
              onClick={() => setActiveTab('screen_search')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition cursor-pointer ${
                activeTab === 'screen_search'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Search className="w-4 h-4 text-purple-600" />
              <span>گەڕانی شاشە و نرخ</span>
            </button>

            <button
              onClick={() => setActiveTab('inventory')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition cursor-pointer ${
                activeTab === 'inventory'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>کۆگای شاشە</span>
            </button>

            <button
              onClick={() => setActiveTab('customers')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition cursor-pointer ${
                activeTab === 'customers'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>وەستاکان و قەرز</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>ڕێکخستنەکان</span>
            </button>

            {/* Lock / Switch to Public Front Page */}
            {onLockToFrontPage && (
              <button
                onClick={onLockToFrontPage}
                title="قفڵکردنی ئەدمین و گەڕانەوە بۆ پەڕەی سەرەکی"
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-slate-600 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
              >
                <Lock className="w-4 h-4 text-slate-400 group-hover:text-rose-600" />
                <span>پەڕەی پێشەوە</span>
              </button>
            )}
          </nav>

          {/* Right Action buttons */}
          <div className="flex items-center gap-2">
            {/* Currency switcher */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-xl text-xs font-mono font-bold">
              <button
                onClick={() => setCurrency('IQD')}
                className={`px-2 py-1 rounded-lg transition ${
                  currency === 'IQD' ? 'bg-white text-purple-700 shadow-xs' : 'text-slate-500'
                }`}
              >
                IQD
              </button>
              <button
                onClick={() => setCurrency('USD')}
                className={`px-2 py-1 rounded-lg transition ${
                  currency === 'USD' ? 'bg-white text-purple-700 shadow-xs' : 'text-slate-500'
                }`}
              >
                $
              </button>
            </div>

            {/* New Invoice Button */}
            <button
              onClick={onOpenNewInvoice}
              className="flex items-center gap-1 px-3.5 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-md cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">وەسڵی نوێ</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="flex md:hidden items-center justify-between py-2 border-t border-slate-100 text-xs font-bold text-slate-600 overflow-x-auto gap-1">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${
              activeTab === 'dashboard' ? 'text-purple-700 bg-purple-50 font-black' : ''
            }`}
          >
            داشبۆرد
          </button>
          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${
              activeTab === 'inventory' ? 'text-purple-700 bg-purple-50 font-black' : ''
            }`}
          >
            کۆگای شاشە
          </button>
          <button
            onClick={() => setActiveTab('customers')}
            className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${
              activeTab === 'customers' ? 'text-purple-700 bg-purple-50 font-black' : ''
            }`}
          >
            وەستاکان
          </button>
          <button
            onClick={() => setActiveTab('customer_portal')}
            className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${
              activeTab === 'customer_portal' ? 'text-purple-700 bg-purple-50 font-black' : ''
            }`}
          >
            پۆرتاڵی وەستا
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-2.5 py-1 rounded-lg whitespace-nowrap ${
              activeTab === 'settings' ? 'text-purple-700 bg-purple-50 font-black' : ''
            }`}
          >
            ڕێکخستن
          </button>
          {onLockToFrontPage && (
            <button
              onClick={onLockToFrontPage}
              className="px-2.5 py-1 rounded-lg whitespace-nowrap text-rose-600 font-bold bg-rose-50 flex items-center gap-1"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>پەڕەی پێشەوە</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
