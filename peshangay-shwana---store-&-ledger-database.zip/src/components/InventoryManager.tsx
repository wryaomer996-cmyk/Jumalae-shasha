import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductItem } from '../types';
import { 
  Package, 
  Search, 
  Plus, 
  Smartphone, 
  Headphones, 
  Wrench, 
  Layers, 
  AlertTriangle, 
  Edit, 
  Trash2, 
  Check, 
  DollarSign,
  Tag,
  Download,
  History,
  TrendingDown,
  TrendingUp,
  ArrowRightLeft,
  RotateCcw
} from 'lucide-react';

export const InventoryManager: React.FC = () => {
  const { 
    products, 
    settings, 
    addProduct, 
    updateProduct, 
    deleteProduct, 
    formatMoney, 
    lowStockProducts,
    stockLogs,
    exportTableAsCsv
  } = useStore();

  const [activeTab, setActiveTab] = useState<'products' | 'history'>('products');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [category, setCategory] = useState<'screen' | 'accessory' | 'part' | 'phone'>('screen');
  const [brand, setBrand] = useState('Apple');
  const [screenModel, setScreenModel] = useState('iPhone 11');
  const [screenQuality, setScreenQuality] = useState<'Original Service Pack' | 'OLED' | 'Incell' | 'TFT' | 'Normal'>('OLED');
  const [costPrice, setCostPrice] = useState<number>(0);
  const [sellPrice, setSellPrice] = useState<number>(0);
  const [quantity, setQuantity] = useState<number>(5);

  const threshold = settings.lowStockThreshold ?? 2;

  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.screenModel && p.screenModel.toLowerCase().includes(searchTerm.toLowerCase())) ||
      p.brand.toLowerCase().includes(searchTerm.toLowerCase());

    if (selectedCategory === 'low_stock') {
      return matchesSearch && p.quantity <= threshold;
    }
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const filteredLogs = stockLogs.filter((l) =>
    l.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (l.notes && l.notes.toLowerCase().includes(searchTerm.toLowerCase())) ||
    (l.invoiceId && l.invoiceId.toString().includes(searchTerm))
  );

  const handleOpenAdd = () => {
    setEditingProduct(null);
    setName('');
    setCategory('screen');
    setBrand('Apple');
    setScreenModel('iPhone 12 / 12 Pro');
    setScreenQuality('OLED');
    setCostPrice(0);
    setSellPrice(0);
    setQuantity(5);
    setShowModal(true);
  };

  const handleOpenEdit = (prod: ProductItem) => {
    setEditingProduct(prod);
    setName(prod.name);
    setCategory(prod.category);
    setBrand(prod.brand);
    setScreenModel(prod.screenModel || '');
    setScreenQuality(prod.screenQuality || 'OLED');
    setCostPrice(prod.costPrice);
    setSellPrice(prod.sellPrice);
    setQuantity(prod.quantity);
    setShowModal(true);
  };

  const handleQuickRestock = (prod: ProductItem, amountToAdd: number) => {
    updateProduct(prod.id, {
      quantity: prod.quantity + amountToAdd,
    });
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || sellPrice <= 0) return;

    if (editingProduct) {
      updateProduct(editingProduct.id, {
        name,
        category,
        brand,
        screenModel: category === 'screen' ? screenModel : undefined,
        screenQuality: category === 'screen' ? screenQuality : undefined,
        costPrice: Number(costPrice) || 0,
        sellPrice: Number(sellPrice) || 0,
        quantity: Number(quantity) || 0,
      });
    } else {
      addProduct({
        name,
        category,
        brand,
        screenModel: category === 'screen' ? screenModel : undefined,
        screenQuality: category === 'screen' ? screenQuality : undefined,
        condition: 'new',
        costPrice: Number(costPrice) || 0,
        sellPrice: Number(sellPrice) || 0,
        quantity: Number(quantity) || 0,
      });
    }

    setShowModal(false);
  };

  const totalInventoryWholesaleValue = products.reduce((sum, p) => sum + p.sellPrice * p.quantity, 0);
  const totalScreensCount = products.filter((p) => p.category === 'screen').reduce((sum, p) => sum + p.quantity, 0);

  return (
    <div className="space-y-6">
      {/* Top Header & View Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <Layers className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-black text-slate-800">
              کۆگای جوملەی شاشە و کەلوپەل (Wholesale Inventory)
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            دیاریکردنی نرخی شاشەکان بۆ وەستاکان، کواڵیتی، ئاگاداری کەمیی کۆگا و مێژووی جووڵەکان
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Tab Switcher */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('products')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>لیستی کاڵاکان ({products.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>مێژووی جووڵەی کۆگا ({stockLogs.length})</span>
            </button>
          </div>

          <button
            onClick={() => exportTableAsCsv(activeTab === 'products' ? 'products' : 'stockLogs')}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer border border-slate-200"
            title="هەناردەکردنی ئەم خشتەیە بۆ فایلی Excel (CSV)"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">Excel</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>زیادکردنی شاشەی نوێ</span>
          </button>
        </div>
      </div>

      {/* Low Stock Alert Banner (Real-time Notification) */}
      {lowStockProducts.length > 0 && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-200 rounded-3xl p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-sm">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-amber-950 flex items-center gap-2">
                  <span>ئاگاداری کەمیی مەوجوودی لە کۆگا!</span>
                  <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-200 text-amber-900">
                    {lowStockProducts.length} دانە کاڵا پێویستی بە کڕینەوە هەیە
                  </span>
                </h3>
                <p className="text-xs text-amber-800 mt-1">
                  ئەم شاشە و کەلوپەلانەی خوارەوە ژمارەیان گەیشتووەتە کەمتر لە {threshold} دانە.
                </p>

                {/* Badges preview */}
                <div className="flex flex-wrap gap-2 mt-3">
                  {lowStockProducts.slice(0, 5).map((p) => (
                    <div
                      key={p.id}
                      className="bg-white/90 border border-amber-300 rounded-xl px-2.5 py-1 text-xs flex items-center gap-2 shadow-2xs"
                    >
                      <span className="font-bold text-slate-800">{p.name}</span>
                      <span className={`font-mono font-black px-1.5 py-0.2 rounded text-[11px] ${
                        p.quantity === 0 ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {p.quantity === 0 ? 'تەواوبووە' : `${p.quantity} دانە ماوە`}
                      </span>
                      <button
                        onClick={() => handleQuickRestock(p, 5)}
                        className="text-[10px] font-bold text-purple-700 hover:text-purple-900 bg-purple-50 hover:bg-purple-100 px-1.5 py-0.5 rounded transition cursor-pointer"
                        title="خێرا زیادکردنی 5 دانە بۆ کۆگا"
                      >
                        +5 زیادبکە
                      </button>
                    </div>
                  ))}
                  {lowStockProducts.length > 5 && (
                    <span className="text-xs font-bold text-amber-800 self-center">
                      +{lowStockProducts.length - 5} کاڵای تر...
                    </span>
                  )}
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setActiveTab('products');
                setSelectedCategory('low_stock');
              }}
              className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer whitespace-nowrap self-center"
            >
              بینینی هەموو کەمییەکان
            </button>
          </div>
        </div>
      )}

      {/* KPI mini row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">کۆی شاشەی مەوجوود:</span>
            <span className="text-lg font-black text-slate-900 font-mono">{totalScreensCount} دانە</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">بەهای شاشەکان بە جوملە:</span>
            <span className="text-lg font-black text-emerald-700 font-mono">
              {totalInventoryWholesaleValue.toLocaleString()} دینار
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
            <Tag className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">نرخی 100 دۆلار بۆ وەستا:</span>
            <span className="text-lg font-black text-indigo-700 font-mono">
              {(settings.usdToIqdRate || 152000).toLocaleString()} دینار
            </span>
          </div>
        </div>
      </div>

      {activeTab === 'products' ? (
        <>
          {/* Search & Filter Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              {[
                { id: 'all', label: 'هەموو کەلوپەلەکان' },
                { id: 'low_stock', label: `⚠️ کەمبووەوە (${lowStockProducts.length})` },
                { id: 'screen', label: '📱 شاشەی مۆبایل (Screens)' },
                { id: 'accessory', label: '🛡️ لەزگە و چەسپ (Accessories)' },
                { id: 'part', label: '🔋 پاتری و پارچە (Parts)' },
                { id: 'phone', label: '📲 ئامێری مۆبایل (Phones)' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedCategory(tab.id)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    selectedCategory === tab.id
                      ? tab.id === 'low_stock'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-purple-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="گەڕان بەدوای شاشە، مۆدێل..."
                className="bg-white border border-slate-200 rounded-xl pr-9 pl-4 py-2 text-xs font-bold focus:outline-purple-600 w-56"
              />
            </div>
          </div>

          {/* Products Table */}
          <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/70">
                    <th className="py-3 px-3">ناوی شاشە / ماددە</th>
                    <th className="py-3 px-3">جۆر و مارکە</th>
                    <th className="py-3 px-3">کواڵیتی</th>
                    <th className="py-3 px-3 text-left">نرخی تێچوون</th>
                    <th className="py-3 px-3 text-left">نرخی جوملە (دینار)</th>
                    <th className="py-3 px-3 text-left">نرخی دۆلار ($)</th>
                    <th className="py-3 px-3 text-center">ژمارە (Stock)</th>
                    <th className="py-3 px-3 text-center">کردارەکان</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {filteredProducts.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-400 font-bold">
                        هیچ کاڵایەک نەدۆزرایەوە بەپێی ئەم فلتەرە.
                      </td>
                    </tr>
                  ) : (
                    filteredProducts.map((p) => {
                      const dollarPrice = p.sellPrice / ((settings.usdToIqdRate || 152000) / 100);
                      const isLow = p.quantity <= threshold;

                      return (
                        <tr key={p.id} className="hover:bg-purple-50/30 transition">
                          <td className="py-3 px-3">
                            <div className="font-bold text-slate-900">{p.name}</div>
                            {p.screenModel && (
                              <span className="text-[11px] text-slate-400 font-mono block">
                                مۆدێل: {p.screenModel}
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-3">
                            <span className="inline-block px-2 py-0.5 rounded-md text-xs font-bold bg-slate-100 text-slate-700">
                              {p.brand}
                            </span>
                          </td>

                          <td className="py-3 px-3">
                            {p.screenQuality ? (
                              <span className="inline-block px-2 py-0.5 rounded-md text-[11px] font-bold bg-purple-100 text-purple-700">
                                {p.screenQuality}
                              </span>
                            ) : (
                              <span className="text-slate-400 text-xs">-</span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-left font-mono text-slate-500">
                            {p.costPrice > 0 ? `${p.costPrice.toLocaleString()}` : '-'}
                          </td>

                          <td className="py-3 px-3 text-left font-mono font-bold text-purple-700 text-sm">
                            {p.sellPrice.toLocaleString()} دینار
                          </td>

                          <td className="py-3 px-3 text-left font-mono font-bold text-slate-600">
                            ${dollarPrice.toFixed(2)}
                          </td>

                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <span
                                className={`inline-block px-2.5 py-1 rounded-full text-xs font-mono font-bold ${
                                  p.quantity === 0
                                    ? 'bg-rose-100 text-rose-700 border border-rose-200'
                                    : isLow
                                    ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                    : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {p.quantity} دانە
                              </span>
                              <button
                                onClick={() => handleQuickRestock(p, 5)}
                                className="px-1.5 py-0.5 bg-purple-50 hover:bg-purple-100 text-purple-700 text-[10px] font-bold rounded-md border border-purple-200 transition cursor-pointer"
                                title="زیادکردنی خێرای 5 دانەی تر بۆ مەوجوودی"
                              >
                                +5
                              </button>
                            </div>
                          </td>

                          <td className="py-3 px-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => handleOpenEdit(p)}
                                className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                                title="دەستکاریکردن"
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`ئایا دڵنیایت لە سڕینەوەی "${p.name}"؟`)) {
                                    deleteProduct(p.id);
                                  }
                                }}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                title="سڕینەوە"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* Stock Movement History View */
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-200 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-800 text-sm sm:text-base flex items-center gap-2">
                <History className="w-4 h-4 text-purple-600" />
                <span>مێژووی جووڵەی کاڵاکان و تۆماری کڕین و فرۆشتن (Stock Logs)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                هەموو فرۆشتن بە وەسڵ، کڕینی نوێ، یان دەستکاریکردنی مەوجوودی بە بەروار و کات لێرەدا دەپارێزرێت.
              </p>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="گەڕان بەپێی کاڵا یان ژمارەی وەسڵ..."
                className="bg-slate-50 border border-slate-200 rounded-xl pr-9 pl-4 py-2 text-xs font-bold focus:outline-purple-600 w-64"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/70">
                  <th className="py-3 px-3">ناوی کاڵا</th>
                  <th className="py-3 px-3">جۆری جووڵە</th>
                  <th className="py-3 px-3 text-center">بڕی گۆڕانکاری</th>
                  <th className="py-3 px-3 text-center">مەوجوودی پێشوو</th>
                  <th className="py-3 px-3 text-center">مەوجوودی نوێ</th>
                  <th className="py-3 px-3 text-center">ژمارەی وەسڵ</th>
                  <th className="py-3 px-3 text-left">بەروار و کات</th>
                  <th className="py-3 px-3">تێبینی</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {filteredLogs.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-slate-400 font-bold">
                      هیچ تۆمارێکی جووڵەی کۆگا نەدۆزرایەوە.
                    </td>
                  </tr>
                ) : (
                  filteredLogs.map((log) => {
                    const isPositive = log.change > 0;
                    return (
                      <tr key={log.id} className="hover:bg-slate-50/60 transition">
                        <td className="py-3 px-3 font-bold text-slate-900">
                          {log.productName}
                        </td>
                        <td className="py-3 px-3">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                              log.type === 'sale'
                                ? 'bg-rose-50 text-rose-700'
                                : log.type === 'purchase'
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-blue-50 text-blue-700'
                            }`}
                          >
                            {log.type === 'sale' ? (
                              <>
                                <TrendingDown className="w-3 h-3" />
                                <span>فرۆشتن</span>
                              </>
                            ) : log.type === 'purchase' ? (
                              <>
                                <TrendingUp className="w-3 h-3" />
                                <span>کڕین / داخڵکردن</span>
                              </>
                            ) : (
                              <>
                                <ArrowRightLeft className="w-3 h-3" />
                                <span>دەستکاری</span>
                              </>
                            )}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-black">
                          <span
                            className={`px-2 py-0.5 rounded-md text-xs ${
                              isPositive
                                ? 'text-emerald-700 bg-emerald-50'
                                : 'text-rose-700 bg-rose-50'
                            }`}
                          >
                            {isPositive ? `+${log.change}` : log.change} دانە
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-mono text-slate-500">
                          {log.previousQuantity}
                        </td>
                        <td className="py-3 px-3 text-center font-mono font-bold text-slate-800">
                          {log.newQuantity}
                        </td>
                        <td className="py-3 px-3 text-center font-mono">
                          {log.invoiceId ? (
                            <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded-md font-bold text-xs">
                              #{log.invoiceId}
                            </span>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-left font-mono text-xs text-slate-500" dir="ltr">
                          {log.date}
                        </td>
                        <td className="py-3 px-3 text-xs text-slate-600">
                          {log.notes || '-'}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white text-slate-800 rounded-3xl p-6 shadow-2xl border border-slate-200">
            <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2">
              <Layers className="w-5 h-5 text-purple-600" />
              <span>{editingProduct ? 'دەستکاریکردنی شاشە / ماددە' : 'تۆمارکردنی شاشەی نوێ'}</span>
            </h3>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ناوی تەواوی شاشە / ماددە:</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="نموونە: شاشەی iPhone 13 Pro Max OLED ئەسڵی"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-purple-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">بەش:</label>
                  <select
                    value={category}
                    onChange={(e: any) => setCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-purple-600"
                  >
                    <option value="screen">📱 شاشەی مۆبایل</option>
                    <option value="accessory">🛡️ لەزگە و چەسپ</option>
                    <option value="part">🔋 پاتری و پارچە</option>
                    <option value="phone">📲 ئامێری مۆبایل</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">مارکە (Brand):</label>
                  <select
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-purple-600"
                  >
                    <option value="Apple">Apple (ئایفۆن)</option>
                    <option value="Samsung">Samsung (سامسۆنگ)</option>
                    <option value="Xiaomi">Xiaomi (شیاومی)</option>
                    <option value="Honor">Honor (هۆنەر)</option>
                    <option value="Huawei">Huawei</option>
                    <option value="Infinix">Infinix</option>
                    <option value="King Kong">King Kong</option>
                    <option value="Other">هیتر</option>
                  </select>
                </div>
              </div>

              {category === 'screen' && (
                <div className="grid grid-cols-2 gap-3 bg-purple-50/60 p-3 rounded-2xl border border-purple-100">
                  <div>
                    <label className="block text-xs font-bold text-purple-900 mb-1">مۆدێلی مۆبایل:</label>
                    <input
                      type="text"
                      value={screenModel}
                      onChange={(e) => setScreenModel(e.target.value)}
                      placeholder="iPhone 13, A54..."
                      className="w-full bg-white border border-purple-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-purple-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-purple-900 mb-1">کواڵیتی شاشە:</label>
                    <select
                      value={screenQuality}
                      onChange={(e: any) => setScreenQuality(e.target.value)}
                      className="w-full bg-white border border-purple-200 rounded-xl px-3 py-2 text-xs font-bold focus:outline-purple-600"
                    >
                      <option value="Original Service Pack">ئەسڵی کارگە (Service Pack)</option>
                      <option value="OLED">OLED ئەسڵی</option>
                      <option value="Incell">Incell کواڵیتی بەرز</option>
                      <option value="TFT">TFT / ئاسایی</option>
                    </select>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">تێچوون (دینار):</label>
                  <input
                    type="number"
                    value={costPrice || ''}
                    onChange={(e) => setCostPrice(Number(e.target.value))}
                    placeholder="0"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold focus:outline-purple-600 text-left"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">نرخی جوملە بۆ وەستا:</label>
                  <input
                    type="number"
                    required
                    min={500}
                    value={sellPrice || ''}
                    onChange={(e) => setSellPrice(Number(e.target.value))}
                    placeholder="0"
                    className="w-full bg-slate-50 border border-purple-300 rounded-xl px-3 py-2 text-xs font-mono font-black text-purple-700 focus:outline-purple-600 text-left"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">ژمارەی مەوجوود:</label>
                  <input
                    type="number"
                    min={0}
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-mono font-bold text-center focus:outline-purple-600"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  پاشگەزبوونەوە
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-sm"
                >
                  پاشەکەوتکردن
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
