export type CurrencyType = 'IQD' | 'USD';

export interface ShopSettings {
  shopName: string;
  subTitle: string;
  ownerName: string;
  phone1: string;
  phone2?: string;
  address: string;
  adminPin: string;
  adminRecoveryKey?: string; // Master recovery code for emergency reset e.g. "HAWTA-996-SECURE"
  securityQuestion?: string; // Secret security question
  securityAnswer?: string; // Secret answer
  recoveryEmail?: string; // Email to receive password resets e.g. wryaomer996@gmail.com
  usdToIqdRate: number; // e.g. 152000 for 100$
  warrantyTerms: string;
  lowStockThreshold?: number; // e.g. 2
  thermalPaperWidth?: '80mm' | '58mm' | 'standard';
  backupEmail?: string;
}

export interface Customer {
  id: number;
  name: string;
  phone: string;
  address: string;
  passcode: string;
  notes?: string;
  createdAt: string;
  totalDebt?: number;
}

export interface InvoiceItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  total: number;
  quality?: string;
  imei?: string;
  notes?: string;
}

export interface Invoice {
  id: number;
  customerId: number;
  date: string;
  branch: string;
  type: 'Sale' | 'Wholesale' | 'Screen' | 'Return';
  items: InvoiceItem[];
  totalAmount: number;
  paidAmount: number;
  discount: number;
  remainingDebt: number;
  previousDebt: number;
  currency: CurrencyType;
  notes?: string;
}

export interface ProductItem {
  id: string;
  name: string;
  category: 'screen' | 'phone' | 'accessory' | 'part';
  brand: string;
  screenModel?: string;
  screenQuality?: 'Original Service Pack' | 'OLED' | 'Incell' | 'TFT' | 'Normal';
  storage?: string;
  color?: string;
  batteryHealth?: number;
  condition: 'new' | 'used';
  imei?: string;
  costPrice: number;
  sellPrice: number; // Wholesale selling price
  quantity: number;
}

export interface PaymentTransaction {
  id: string;
  customerId: number;
  customerName: string;
  amount: number;
  currency: CurrencyType;
  date: string;
  type: 'payment' | 'refund' | 'adjustment';
  notes?: string;
  receivedBy: string;
}

export interface StockMovementLog {
  id: string;
  productId: string;
  productName: string;
  type: 'sale' | 'purchase' | 'adjustment' | 'return';
  change: number; // e.g. -1 for sale, +5 for restock
  previousQuantity: number;
  newQuantity: number;
  date: string;
  invoiceId?: number;
  notes?: string;
}

export interface DailyBackupSnapshot {
  id: string;
  date: string; // YYYY-MM-DD
  timestamp: string; // ISO string
  customersCount: number;
  invoicesCount: number;
  productsCount: number;
  dataJson: string;
}

