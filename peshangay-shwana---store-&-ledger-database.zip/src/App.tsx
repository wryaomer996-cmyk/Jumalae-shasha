import React, { useState } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Navbar, ActiveTab } from './components/Navbar';
import { CustomerPortal } from './components/CustomerPortal';
import { AdminDashboard } from './components/AdminDashboard';
import { CustomersManager } from './components/CustomersManager';
import { InventoryManager } from './components/InventoryManager';
import { SettingsManager } from './components/SettingsManager';
import { QuickScreenSearch } from './components/QuickScreenSearch';
import { NewInvoiceModal } from './components/NewInvoiceModal';
import { InvoiceReceiptModal } from './components/InvoiceReceiptModal';
import { Invoice } from './types';
import { 
  LayoutDashboard, 
  Layers, 
  Users, 
  Settings, 
  UserCheck, 
  PlusCircle,
  Plus,
  Search
} from 'lucide-react';

function MainApp() {
  const { invoices } = useStore();

  // Mode: Default to Public Front Page (Customer Portal & Read-only Screen catalog)
  const [activeTab, setActiveTab] = useState<ActiveTab>(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('portal') === 'true') {
      return 'customer_portal';
    }
    if (params.get('admin') === 'true') {
      return 'dashboard';
    }
    const savedAdmin = sessionStorage.getItem('admin_session_unlocked');
    if (savedAdmin === 'true') {
      return 'dashboard';
    }
    return 'customer_portal';
  });

  // Selected customer ID: only set if explicitly passed in URL, else undefined (neutral login)
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | undefined>(() => {
    const params = new URLSearchParams(window.location.search);
    const cid = params.get('customer_id');
    return cid ? Number(cid) : undefined;
  });

  const [showNewInvoiceModal, setShowNewInvoiceModal] = useState(false);
  const [invoiceToView, setInvoiceToView] = useState<Invoice | null>(null);

  const handleOpenCustomerPortal = (customerId?: number) => {
    setSelectedCustomerId(customerId);
    setActiveTab('customer_portal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSwitchToAdmin = () => {
    sessionStorage.setItem('admin_session_unlocked', 'true');
    setActiveTab('dashboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLockToFrontPage = () => {
    sessionStorage.removeItem('admin_session_unlocked');
    setSelectedCustomerId(undefined);
    setActiveTab('customer_portal');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleInvoiceCreated = (invoiceId: number) => {
    setShowNewInvoiceModal(false);
    const created = invoices.find((i) => i.id === invoiceId);
    if (created) {
      setInvoiceToView(created);
    }
  };

  // If in customer portal mode, display the public Front Page and technician portal
  // Technicians cannot access admin without entering Admin PIN
  const isCustomerPortalMode = activeTab === 'customer_portal';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-purple-200 selection:text-purple-900" dir="rtl">
      {/* Top Navigation - shown in Admin mode */}
      {!isCustomerPortalMode && (
        <Navbar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenNewInvoice={() => setShowNewInvoiceModal(true)}
          selectedCustomerId={selectedCustomerId}
          setSelectedCustomerId={setSelectedCustomerId}
          onLockToFrontPage={handleLockToFrontPage}
        />
      )}

      {/* Main Content Area */}
      <main className={isCustomerPortalMode ? 'flex-1' : 'flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 pb-24 md:pb-8'}>
        {activeTab === 'customer_portal' && (
          <CustomerPortal
            selectedCustomerId={selectedCustomerId}
            onSwitchToAdmin={handleSwitchToAdmin}
          />
        )}

        {activeTab === 'dashboard' && (
          <AdminDashboard
            onOpenNewInvoice={() => setShowNewInvoiceModal(true)}
            onOpenCustomers={() => setActiveTab('customers')}
            onOpenInventory={() => setActiveTab('inventory')}
            onOpenSettings={() => setActiveTab('settings')}
            onOpenCustomerPortal={handleOpenCustomerPortal}
            onLockToFrontPage={handleLockToFrontPage}
          />
        )}

        {activeTab === 'screen_search' && (
          <QuickScreenSearch
            onOpenNewInvoice={() => setShowNewInvoiceModal(true)}
            fullPage
          />
        )}

        {activeTab === 'customers' && (
          <CustomersManager onOpenCustomerPortal={handleOpenCustomerPortal} />
        )}

        {activeTab === 'inventory' && <InventoryManager />}

        {activeTab === 'settings' && <SettingsManager />}
      </main>

      {/* Mobile Bottom Dock for Admin Mode (< md:) */}
      {!isCustomerPortalMode && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-slate-200 shadow-2xl px-2 py-2 flex items-center justify-around text-[10px] font-bold text-slate-600">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'dashboard' ? 'text-purple-700 font-black' : 'hover:text-slate-900'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>داشبۆرد</span>
          </button>

          <button
            onClick={() => setActiveTab('screen_search')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'screen_search' ? 'text-purple-700 font-black' : 'hover:text-slate-900'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>گەڕان</span>
          </button>

          {/* Quick New Invoice Floating Center Button */}
          <button
            onClick={() => setShowNewInvoiceModal(true)}
            className="flex flex-col items-center justify-center -mt-5 w-11 h-11 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 text-white shadow-lg shadow-purple-600/40 cursor-pointer active:scale-95 transition"
            title="وەسڵی نوێ"
          >
            <Plus className="w-6 h-6" />
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'inventory' ? 'text-purple-700 font-black' : 'hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>شاشەکان</span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'customers' ? 'text-purple-700 font-black' : 'hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>وەستاکان</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`flex flex-col items-center gap-1 p-1 rounded-xl transition cursor-pointer ${
              activeTab === 'settings' ? 'text-purple-700 font-black' : 'hover:text-slate-900'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>ڕێکخستن</span>
          </button>
        </div>
      )}

      {/* Modals */}
      {showNewInvoiceModal && (
        <NewInvoiceModal
          onClose={() => setShowNewInvoiceModal(false)}
          onInvoiceCreated={handleInvoiceCreated}
          initialCustomerId={selectedCustomerId}
        />
      )}

      {invoiceToView && (
        <InvoiceReceiptModal
          invoice={invoiceToView}
          onClose={() => setInvoiceToView(null)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <MainApp />
    </StoreProvider>
  );
}
