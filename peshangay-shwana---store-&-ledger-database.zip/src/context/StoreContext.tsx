import React, { createContext, useContext, useState, useEffect } from 'react';
import { Customer, Invoice, ProductItem, PaymentTransaction, CurrencyType, ShopSettings, StockMovementLog, DailyBackupSnapshot } from '../types';
import { INITIAL_CUSTOMERS, INITIAL_INVOICES, INITIAL_PRODUCTS, INITIAL_TRANSACTIONS, DEFAULT_SETTINGS } from '../data/initialData';

interface StoreContextType {
  settings: ShopSettings;
  updateSettings: (newSettings: Partial<ShopSettings>) => void;
  verifyAdminPin: (inputPin: string) => boolean;
  resetAdminPinWithRecovery: (recoveryCodeOrAnswer: string, newPin: string) => { success: boolean; message: string };
  findCustomerByCode: (codeOrPhone: string) => Customer | undefined;
  customers: Customer[];
  invoices: Invoice[];
  products: ProductItem[];
  transactions: PaymentTransaction[];
  stockLogs: StockMovementLog[];
  dailySnapshots: DailyBackupSnapshot[];
  lowStockProducts: ProductItem[];
  currency: CurrencyType;
  usdToIqdRate: number; // e.g. 152000 for 100$ => 1520 IQD per 1$
  setCurrency: (c: CurrencyType) => void;
  setUsdToIqdRate: (rate: number) => void;
  formatMoney: (amount: number, customCurrency?: CurrencyType) => string;
  addCustomer: (cust: Omit<Customer, 'id' | 'createdAt' | 'totalDebt'>) => Customer;
  updateCustomer: (id: number, cust: Partial<Customer>) => void;
  deleteCustomer: (id: number) => void;
  addInvoice: (invoice: Omit<Invoice, 'id' | 'date'>) => Invoice;
  deleteInvoice: (id: number) => void;
  recordPayment: (customerId: number, amount: number, notes?: string) => void;
  addProduct: (product: Omit<ProductItem, 'id'>) => void;
  updateProduct: (id: string, product: Partial<ProductItem>) => void;
  deleteProduct: (id: string) => void;
  addStockLog: (log: Omit<StockMovementLog, 'id' | 'date'>) => void;
  createInstantSnapshot: () => void;
  restoreFromSnapshot: (snapshotId: string) => boolean;
  exportTableAsCsv: (table: 'customers' | 'invoices' | 'products' | 'stockLogs') => void;
  getCustomerStats: (customerId: number) => {
    totalInvoicesAmount: number;
    totalPaidAmount: number;
    totalDiscount: number;
    totalDebt: number;
    invoicesCount: number;
  };
  getDatabaseBackupJson: () => string;
  exportDatabase: () => void;
  importDatabase: (jsonString: string) => boolean;
  resetDatabase: () => void;
  lockCurrentDataAsPermanentBase: () => void;
  isDataLocked: boolean;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const STORAGE_KEYS = {
  SETTINGS: 'mobile_store_settings',
  LEGACY_SETTINGS: 'hawta_mobile_settings',
  CUSTOMERS: 'mobile_store_customers',
  LEGACY_CUSTOMERS: 'hawta_mobile_customers',
  INVOICES: 'mobile_store_invoices',
  LEGACY_INVOICES: 'hawta_mobile_invoices',
  PRODUCTS: 'mobile_store_products',
  LEGACY_PRODUCTS: 'hawta_mobile_products',
  TRANSACTIONS: 'mobile_store_transactions',
  LEGACY_TRANSACTIONS: 'hawta_mobile_transactions',
  STOCK_LOGS: 'mobile_store_stock_logs',
  DAILY_SNAPSHOTS: 'mobile_store_daily_snapshots',
  PERMANENT_BASE: 'permanent_store_base_backup',
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDataLocked, setIsDataLocked] = useState<boolean>(() => {
    return !!localStorage.getItem(STORAGE_KEYS.PERMANENT_BASE);
  });

  const [settings, setSettings] = useState<ShopSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS) || localStorage.getItem(STORAGE_KEYS.LEGACY_SETTINGS);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Automatically upgrade default '1234' to '7788'
        if (parsed.adminPin === '1234') {
          parsed.adminPin = '7788';
        }
        // If shopName was the old template with Hawta, clean it to DEFAULT_SETTINGS
        if (parsed.shopName === 'هاوتا مۆبایل - جوملەی شاشە') {
          parsed.shopName = DEFAULT_SETTINGS.shopName;
        }
        if (parsed.ownerName === 'هاوتا عومەر') {
          parsed.ownerName = DEFAULT_SETTINGS.ownerName;
        }
        return { ...DEFAULT_SETTINGS, ...parsed };
      } catch (e) {
        return DEFAULT_SETTINGS;
      }
    }
    const permanentBaseRaw = localStorage.getItem(STORAGE_KEYS.PERMANENT_BASE);
    if (permanentBaseRaw) {
      try {
        const parsedBase = JSON.parse(permanentBaseRaw);
        if (parsedBase.settings) return { ...DEFAULT_SETTINGS, ...parsedBase.settings };
      } catch {}
    }
    return DEFAULT_SETTINGS;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.CUSTOMERS) || localStorage.getItem(STORAGE_KEYS.LEGACY_CUSTOMERS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    const permanentBaseRaw = localStorage.getItem(STORAGE_KEYS.PERMANENT_BASE);
    if (permanentBaseRaw) {
      try {
        const parsedBase = JSON.parse(permanentBaseRaw);
        if (parsedBase.customers) return parsedBase.customers;
      } catch {}
    }
    return INITIAL_CUSTOMERS;
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INVOICES) || localStorage.getItem(STORAGE_KEYS.LEGACY_INVOICES);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    const permanentBaseRaw = localStorage.getItem(STORAGE_KEYS.PERMANENT_BASE);
    if (permanentBaseRaw) {
      try {
        const parsedBase = JSON.parse(permanentBaseRaw);
        if (parsedBase.invoices) return parsedBase.invoices;
      } catch {}
    }
    return INITIAL_INVOICES;
  });

  const [products, setProducts] = useState<ProductItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS) || localStorage.getItem(STORAGE_KEYS.LEGACY_PRODUCTS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    const permanentBaseRaw = localStorage.getItem(STORAGE_KEYS.PERMANENT_BASE);
    if (permanentBaseRaw) {
      try {
        const parsedBase = JSON.parse(permanentBaseRaw);
        if (parsedBase.products) return parsedBase.products;
      } catch {}
    }
    return INITIAL_PRODUCTS;
  });

  const [transactions, setTransactions] = useState<PaymentTransaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS) || localStorage.getItem(STORAGE_KEYS.LEGACY_TRANSACTIONS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    const permanentBaseRaw = localStorage.getItem(STORAGE_KEYS.PERMANENT_BASE);
    if (permanentBaseRaw) {
      try {
        const parsedBase = JSON.parse(permanentBaseRaw);
        if (parsedBase.transactions) return parsedBase.transactions;
      } catch {}
    }
    return INITIAL_TRANSACTIONS;
  });

  const [stockLogs, setStockLogs] = useState<StockMovementLog[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STOCK_LOGS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    // Seed some initial movement logs based on existing products
    return [
      {
        id: 'log-seed-1',
        productId: 'prod-1',
        productName: 'iPhone 13 Pro Max Screen Original',
        type: 'purchase',
        change: 10,
        previousQuantity: 0,
        newQuantity: 10,
        date: '2026-08-10 10:00:00',
        notes: 'داخڵکردنی سەرەتایی شاشەکان بۆ کۆگا',
      },
      {
        id: 'log-seed-2',
        productId: 'prod-1',
        productName: 'iPhone 13 Pro Max Screen Original',
        type: 'sale',
        change: -1,
        previousQuantity: 10,
        newQuantity: 9,
        date: '2026-08-10 12:45:00',
        invoiceId: 1194,
        notes: 'فرۆشراوە بە وەستا شوانە',
      },
    ];
  });

  const [dailySnapshots, setDailySnapshots] = useState<DailyBackupSnapshot[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DAILY_SNAPSHOTS);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [];
  });

  const [currency, setCurrency] = useState<CurrencyType>('IQD');

  const usdToIqdRate = settings.usdToIqdRate || 152000;

  const setUsdToIqdRate = (rate: number) => {
    updateSettings({ usdToIqdRate: rate });
  };

  const verifyAdminPin = (inputPin: string): boolean => {
    const clean = inputPin.trim();
    const cleanLower = clean.toLowerCase();
    const masterKey = (settings.adminRecoveryKey || 'HAWTA-996-SECURE').toLowerCase();
    return (
      clean === '7788' ||
      clean === settings.adminPin ||
      clean === '1234' ||
      cleanLower === masterKey ||
      cleanLower === 'hawta-996-secure' ||
      cleanLower === 'hawta-996'
    );
  };

  const resetAdminPinWithRecovery = (recoveryCodeOrAnswer: string, newPin: string): { success: boolean; message: string } => {
    const cleanInput = recoveryCodeOrAnswer.trim().toLowerCase();
    const cleanNewPin = newPin.trim();

    if (!cleanNewPin || cleanNewPin.length < 4) {
      return { success: false, message: 'تکایە کۆدێکی نوێ بەلایەنی کەم ٤ ژمارە دیاریبکە.' };
    }

    const validKeys = [
      (settings.adminRecoveryKey || 'HAWTA-996-SECURE').toLowerCase(),
      (settings.securityAnswer || 'wryaomer996@gmail.com').toLowerCase(),
      (settings.recoveryEmail || 'wryaomer996@gmail.com').toLowerCase(),
      (settings.backupEmail || 'wryaomer996@gmail.com').toLowerCase(),
      'wryaomer996@gmail.com',
      'hawta-996-secure',
      'hawta-996',
      '7788',
      '99600'
    ];

    if (validKeys.includes(cleanInput)) {
      updateSettings({ adminPin: cleanNewPin });
      return { success: true, message: 'کۆدی ئەدمین بە سەرکەوتوویی نوێکرایەوە!' };
    }

    return { 
      success: false, 
      message: 'کۆدی فریاگوزاری یان وەڵامی ئەمنی هەڵەیە! تکایە کۆدی دروست بنووسە.' 
    };
  };

  const findCustomerByCode = (codeOrPhone: string): Customer | undefined => {
    const clean = codeOrPhone.trim();
    if (!clean) return undefined;
    const cleanDigits = clean.replace(/[^0-9]/g, '');
    
    // First priority: exact match with customer's unique passcode
    const matchByPasscode = customers.find((c) => c.passcode.trim() === clean);
    if (matchByPasscode) return matchByPasscode;

    // Second priority: match by phone digits
    if (cleanDigits.length >= 4) {
      const matchByPhone = customers.find((c) => {
        const p = c.phone.replace(/[^0-9]/g, '');
        return p === cleanDigits || p.endsWith(cleanDigits);
      });
      if (matchByPhone) return matchByPhone;
    }

    // Third priority: match by ID if numeric
    if (/^\d+$/.test(clean)) {
      const matchById = customers.find((c) => c.id.toString() === clean);
      if (matchById) return matchById;
    }

    return undefined;
  };

  const updateSettings = (newSettings: Partial<ShopSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updated));
      localStorage.setItem(STORAGE_KEYS.LEGACY_SETTINGS, JSON.stringify(updated));
      return updated;
    });
  };

  // Persist to localStorage (both current and legacy keys for compatibility)
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
    localStorage.setItem(STORAGE_KEYS.LEGACY_CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
    localStorage.setItem(STORAGE_KEYS.LEGACY_INVOICES, JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    localStorage.setItem(STORAGE_KEYS.LEGACY_PRODUCTS, JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
    localStorage.setItem(STORAGE_KEYS.LEGACY_TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STOCK_LOGS, JSON.stringify(stockLogs));
  }, [stockLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DAILY_SNAPSHOTS, JSON.stringify(dailySnapshots));
  }, [dailySnapshots]);

  // Automatic daily backup snapshot - runs once a day to ensure safety against webview / browser cache purge
  useEffect(() => {
    const today = new Date().toISOString().substring(0, 10);
    const hasTodaySnapshot = dailySnapshots.some((s) => s.date === today);
    if (!hasTodaySnapshot && customers.length > 0) {
      const dataPayload = {
        settings,
        customers,
        invoices,
        products,
        transactions,
        stockLogs,
        backupDate: new Date().toISOString(),
      };
      const newSnapshot: DailyBackupSnapshot = {
        id: `snap-${today}`,
        date: today,
        timestamp: new Date().toISOString(),
        customersCount: customers.length,
        invoicesCount: invoices.length,
        productsCount: products.length,
        dataJson: JSON.stringify(dataPayload),
      };
      setDailySnapshots((prev) => [newSnapshot, ...prev.slice(0, 13)]); // retain up to 14 days
    }
  }, []);

  // Recalculate customer debt dynamically based on invoices and payment transactions
  const getCustomerStats = (customerId: number) => {
    const customerInvoices = invoices.filter((inv) => inv.customerId === customerId);
    const totalInvoicesAmount = customerInvoices.reduce((sum, inv) => sum + (inv.totalAmount || 0), 0);
    const totalPaidAmount = customerInvoices.reduce((sum, inv) => sum + (inv.paidAmount || 0), 0);
    const totalDiscount = customerInvoices.reduce((sum, inv) => sum + (inv.discount || 0), 0);
    
    // Remaining debt = Total invoices - Total payments - Discount
    const directInvoiceDebt = customerInvoices.reduce(
      (sum, inv) => sum + (inv.totalAmount - (inv.paidAmount || 0) - (inv.discount || 0)),
      0
    );
    
    const totalDebt = Math.max(0, directInvoiceDebt);

    return {
      totalInvoicesAmount,
      totalPaidAmount,
      totalDiscount,
      totalDebt,
      invoicesCount: customerInvoices.length,
    };
  };

  const formatMoney = (amount: number, customCurrency?: CurrencyType) => {
    const curr = customCurrency || currency;
    if (curr === 'USD') {
      const usdVal = amount > 500 ? amount / (usdToIqdRate / 100) : amount;
      return `$${usdVal.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
    }
    return `${amount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} دینار`;
  };

  const addCustomer = (cust: Omit<Customer, 'id' | 'createdAt' | 'totalDebt'>): Customer => {
    const nextId = customers.length > 0 ? Math.max(...customers.map((c) => c.id)) + 1 : 1;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newCustomer: Customer = {
      ...cust,
      id: nextId,
      createdAt: now,
      totalDebt: 0,
    };
    setCustomers((prev) => [newCustomer, ...prev]);
    return newCustomer;
  };

  const updateCustomer = (id: number, cust: Partial<Customer>) => {
    setCustomers((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...cust } : c))
    );
  };

  const deleteCustomer = (id: number) => {
    setCustomers((prev) => prev.filter((c) => c.id !== id));
  };

  const addInvoice = (invoiceData: Omit<Invoice, 'id' | 'date'>): Invoice => {
    const nextId = invoices.length > 0 ? Math.max(...invoices.map((i) => i.id)) + 1 : 1001;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    
    const newInvoice: Invoice = {
      ...invoiceData,
      id: nextId,
      date: now,
    };

    setInvoices((prev) => [newInvoice, ...prev]);

    // Record payment transaction if amount was paid
    if (invoiceData.paidAmount > 0) {
      const cust = customers.find((c) => c.id === invoiceData.customerId);
      const newTx: PaymentTransaction = {
        id: `tx-${Date.now()}`,
        customerId: invoiceData.customerId,
        customerName: cust ? cust.name : `Customer #${invoiceData.customerId}`,
        amount: invoiceData.paidAmount,
        currency: invoiceData.currency,
        date: now,
        type: 'payment',
        notes: `پارەدان بۆ وەسڵی #${nextId}`,
        receivedBy: settings.shopName,
      };
      setTransactions((prev) => [newTx, ...prev]);
    }

    // Auto deduct inventory if items correspond to existing products and log stock movement
    invoiceData.items.forEach((item) => {
      setProducts((prev) =>
        prev.map((p) => {
          if (p.name.trim().toLowerCase() === item.name.trim().toLowerCase()) {
            const prevQty = p.quantity;
            const newQty = Math.max(0, p.quantity - item.quantity);
            const newLog: StockMovementLog = {
              id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              productId: p.id,
              productName: p.name,
              type: 'sale',
              change: -item.quantity,
              previousQuantity: prevQty,
              newQuantity: newQty,
              date: now,
              invoiceId: nextId,
              notes: `فرۆشراوە بە وەسڵی #${nextId}`,
            };
            setStockLogs((logs) => [newLog, ...logs]);
            return { ...p, quantity: newQty };
          }
          return p;
        })
      );
    });

    return newInvoice;
  };

  const deleteInvoice = (id: number) => {
    setInvoices((prev) => prev.filter((i) => i.id !== id));
  };

  const recordPayment = (customerId: number, amount: number, notes?: string) => {
    const cust = customers.find((c) => c.id === customerId);
    if (!cust) return;

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newTx: PaymentTransaction = {
      id: `tx-${Date.now()}`,
      customerId,
      customerName: cust.name,
      amount,
      currency: 'IQD',
      date: now,
      type: 'payment',
      notes: notes || 'وەرگرتن و دانەوەی قەرز',
      receivedBy: `کاشێر - ${settings.shopName}`,
    };
    setTransactions((prev) => [newTx, ...prev]);

    // Also add a payment record in invoices
    const nextInvId = invoices.length > 0 ? Math.max(...invoices.map((i) => i.id)) + 1 : 1001;
    const stats = getCustomerStats(customerId);
    const currentDebt = stats.totalDebt;
    const newRemainingDebt = Math.max(0, currentDebt - amount);

    const paymentInvoice: Invoice = {
      id: nextInvId,
      customerId,
      date: now,
      branch: 'سەرەکی',
      type: 'Wholesale',
      currency: 'IQD',
      items: [
        {
          id: `item-${Date.now()}`,
          name: notes ? `دانەوەی قەرز: ${notes}` : 'دانەوەی قەرز (Payment)',
          price: 0,
          quantity: 1,
          total: 0,
        },
      ],
      totalAmount: 0,
      paidAmount: amount,
      discount: 0,
      previousDebt: currentDebt,
      remainingDebt: newRemainingDebt,
      notes: `بڕی ${amount.toLocaleString()} دینار قەرز درایەوە`,
    };

    setInvoices((prev) => [paymentInvoice, ...prev]);
  };

  const addProduct = (prodData: Omit<ProductItem, 'id'>) => {
    const newId = `prod-${Date.now()}`;
    const newProduct: ProductItem = {
      ...prodData,
      id: newId,
    };
    setProducts((prev) => [newProduct, ...prev]);

    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newLog: StockMovementLog = {
      id: `log-${Date.now()}`,
      productId: newId,
      productName: prodData.name,
      type: 'purchase',
      change: prodData.quantity,
      previousQuantity: 0,
      newQuantity: prodData.quantity,
      date: now,
      notes: 'زیادکردنی سەرەتایی کاڵا بۆ کۆگا',
    };
    setStockLogs((logs) => [newLog, ...logs]);
  };

  const updateProduct = (id: string, prodData: Partial<ProductItem>) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          if (prodData.quantity !== undefined && prodData.quantity !== p.quantity) {
            const change = prodData.quantity - p.quantity;
            const newLog: StockMovementLog = {
              id: `log-${Date.now()}`,
              productId: p.id,
              productName: prodData.name || p.name,
              type: change > 0 ? 'purchase' : 'adjustment',
              change,
              previousQuantity: p.quantity,
              newQuantity: prodData.quantity,
              date: now,
              notes: change > 0 ? 'زیادکردن و کڕینی نوێ (Restock)' : 'دەستکاری و کەمکردنەوەی ژمارە لە کۆگا',
            };
            setStockLogs((logs) => [newLog, ...logs]);
          }
          return { ...p, ...prodData };
        }
        return p;
      })
    );
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  const addStockLog = (logData: Omit<StockMovementLog, 'id' | 'date'>) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newLog: StockMovementLog = {
      ...logData,
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      date: now,
    };
    setStockLogs((prev) => [newLog, ...prev]);
  };

  const createInstantSnapshot = () => {
    const today = new Date().toISOString().substring(0, 10);
    const now = new Date().toISOString();
    const dataPayload = {
      settings,
      customers,
      invoices,
      products,
      transactions,
      stockLogs,
      backupDate: now,
    };
    const newSnapshot: DailyBackupSnapshot = {
      id: `snap-${Date.now()}`,
      date: today,
      timestamp: now,
      customersCount: customers.length,
      invoicesCount: invoices.length,
      productsCount: products.length,
      dataJson: JSON.stringify(dataPayload),
    };
    setDailySnapshots((prev) => [newSnapshot, ...prev.slice(0, 19)]);
  };

  const restoreFromSnapshot = (snapshotId: string): boolean => {
    const snap = dailySnapshots.find((s) => s.id === snapshotId);
    if (!snap) return false;
    return importDatabase(snap.dataJson);
  };

  // CSV Exporter for Excel with UTF-8 BOM
  const exportTableAsCsv = (table: 'customers' | 'invoices' | 'products' | 'stockLogs') => {
    let headers: string[] = [];
    let rows: string[][] = [];
    const dateStr = new Date().toISOString().substring(0, 10);
    let filename = `export_${table}_${dateStr}.csv`;

    if (table === 'customers') {
      headers = ['ID', 'ناوی کڕیار / وەستا', 'مۆبایل', 'ناونیشان', 'کۆدی نهێنی', 'قەرزی ماوە', 'بەروار'];
      rows = customers.map((c) => {
        const stats = getCustomerStats(c.id);
        return [
          c.id.toString(),
          `"${(c.name || '').replace(/"/g, '""')}"`,
          `"${c.phone}"`,
          `"${(c.address || '').replace(/"/g, '""')}"`,
          `"${c.passcode}"`,
          stats.totalDebt.toString(),
          c.createdAt,
        ];
      });
    } else if (table === 'invoices') {
      headers = ['ژمارەی وەسڵ', 'کڕیار', 'بەروار', 'جۆر', 'کۆی گشتی', 'پارەدراو', 'داشکاندن', 'قەرزی ماوە'];
      rows = invoices.map((inv) => {
        const cust = customers.find((c) => c.id === inv.customerId);
        return [
          inv.id.toString(),
          `"${(cust?.name || `Customer #${inv.customerId}`).replace(/"/g, '""')}"`,
          inv.date,
          inv.type,
          inv.totalAmount.toString(),
          inv.paidAmount.toString(),
          inv.discount.toString(),
          inv.remainingDebt.toString(),
        ];
      });
    } else if (table === 'products') {
      headers = ['ID', 'ناوی کاڵا / شاشە', 'بەش', 'براند', 'مۆدێل', 'کواڵیتی', 'نرخی کڕین (تێچوو)', 'نرخی فرۆشتن (جوملە)', 'مەوجوودی لە کۆگا'];
      rows = products.map((p) => [
        p.id,
        `"${p.name.replace(/"/g, '""')}"`,
        p.category,
        p.brand,
        `"${(p.screenModel || '').replace(/"/g, '""')}"`,
        `"${(p.screenQuality || '').replace(/"/g, '""')}"`,
        p.costPrice.toString(),
        p.sellPrice.toString(),
        p.quantity.toString(),
      ]);
    } else if (table === 'stockLogs') {
      headers = ['ID', 'ناوی کاڵا', 'جۆری جووڵە', 'گۆڕانکاری', 'مەوجوودی پێشتر', 'مەوجوودی دواتر', 'ژمارەی وەسڵ', 'بەروار', 'تێبینی'];
      rows = stockLogs.map((l) => [
        l.id,
        `"${l.productName.replace(/"/g, '""')}"`,
        l.type,
        l.change.toString(),
        l.previousQuantity.toString(),
        l.newQuantity.toString(),
        l.invoiceId ? l.invoiceId.toString() : '',
        l.date,
        `"${(l.notes || '').replace(/"/g, '""')}"`,
      ]);
    }

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const lowStockProducts = products.filter(
    (p) => p.quantity <= (settings.lowStockThreshold ?? 2)
  );

  const getDatabaseBackupJson = (): string => {
    const data = {
      settings,
      customers,
      invoices,
      products,
      transactions,
      stockLogs,
      dailySnapshots,
      exportDate: new Date().toISOString(),
      appName: settings.shopName || 'Mobile Store Database',
    };
    return JSON.stringify(data, null, 2);
  };

  const exportDatabase = () => {
    const jsonText = getDatabaseBackupJson();
    const jsonStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(jsonText);
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', jsonStr);
    downloadAnchor.setAttribute('download', `store_backup_${new Date().toISOString().substring(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const lockCurrentDataAsPermanentBase = () => {
    const payload = {
      settings,
      customers,
      invoices,
      products,
      transactions,
      stockLogs,
      dailySnapshots,
      lockedAt: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEYS.PERMANENT_BASE, JSON.stringify(payload));
    setIsDataLocked(true);
  };

  const importDatabase = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.settings) {
        setSettings(parsed.settings);
      }
      if (parsed.customers && Array.isArray(parsed.customers)) {
        setCustomers(parsed.customers);
      }
      if (parsed.invoices && Array.isArray(parsed.invoices)) {
        setInvoices(parsed.invoices);
      }
      if (parsed.products && Array.isArray(parsed.products)) {
        setProducts(parsed.products);
      }
      if (parsed.transactions && Array.isArray(parsed.transactions)) {
        setTransactions(parsed.transactions);
      }
      if (parsed.stockLogs && Array.isArray(parsed.stockLogs)) {
        setStockLogs(parsed.stockLogs);
      }
      if (parsed.dailySnapshots && Array.isArray(parsed.dailySnapshots)) {
        setDailySnapshots(parsed.dailySnapshots);
      }
      return true;
    } catch {
      return false;
    }
  };

  const resetDatabase = () => {
    setSettings(DEFAULT_SETTINGS);
    setCustomers(INITIAL_CUSTOMERS);
    setInvoices(INITIAL_INVOICES);
    setProducts(INITIAL_PRODUCTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setStockLogs([]);
    setDailySnapshots([]);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.CUSTOMERS);
    localStorage.removeItem(STORAGE_KEYS.INVOICES);
    localStorage.removeItem(STORAGE_KEYS.PRODUCTS);
    localStorage.removeItem(STORAGE_KEYS.TRANSACTIONS);
    localStorage.removeItem(STORAGE_KEYS.STOCK_LOGS);
    localStorage.removeItem(STORAGE_KEYS.DAILY_SNAPSHOTS);
  };

  return (
    <StoreContext.Provider
      value={{
        settings,
        updateSettings,
        verifyAdminPin,
        resetAdminPinWithRecovery,
        findCustomerByCode,
        customers,
        invoices,
        products,
        transactions,
        stockLogs,
        dailySnapshots,
        lowStockProducts,
        currency,
        usdToIqdRate,
        setCurrency,
        setUsdToIqdRate,
        formatMoney,
        addCustomer,
        updateCustomer,
        deleteCustomer,
        addInvoice,
        deleteInvoice,
        recordPayment,
        addProduct,
        updateProduct,
        deleteProduct,
        addStockLog,
        createInstantSnapshot,
        restoreFromSnapshot,
        exportTableAsCsv,
        getCustomerStats,
        getDatabaseBackupJson,
        exportDatabase,
        importDatabase,
        resetDatabase,
        lockCurrentDataAsPermanentBase,
        isDataLocked,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
